export const __webpack_ids__=["62807"];export const __webpack_modules__={4322:function(a,e,i){i.a(a,(async function(a,e){try{var t=i(44249),n=i(57243),s=i(15093),o=i(36522),c=(i(19993),i(74633),i(42603)),l=i(7111),d=i(26779),h=i(93913),u=a([d]);d=(u.then?(await u)():u)[0];const r="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z";(0,t.Z)([(0,s.Mo)("ha-backup-config-encryption-key")],(function(a,e){return{F:class extends e{constructor(...e){super(...e),a(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"value",value:void 0},{kind:"get",key:"_value",value:function(){return this.value??""}},{kind:"method",key:"render",value:function(){return this._value?n.dy`
        <ha-md-list>
          <ha-md-list-item>
            <span slot="headline">
              ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit")}
            </span>
            <span slot="supporting-text">
              ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_description")}
            </span>
            <ha-button slot="end" @click=${this._download}>
              <ha-svg-icon .path=${r} slot="icon"></ha-svg-icon>
              ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_action")}
            </ha-button>
          </ha-md-list-item>
          <ha-md-list-item>
            <span slot="headline">
              ${this.hass.localize("ui.panel.config.backup.encryption_key.show_encryption_key")}
            </span>
            <span slot="supporting-text">
              ${this.hass.localize("ui.panel.config.backup.encryption_key.show_encryption_key_description")}
            </span>
            <ha-button slot="end" @click=${this._show}>
              ${this.hass.localize("ui.panel.config.backup.encryption_key.show_encryption_key_action")}
            </ha-button>
          </ha-md-list-item>
          <ha-md-list-item>
            <span slot="headline">
              ${this.hass.localize("ui.panel.config.backup.encryption_key.change_encryption_key")}
            </span>
            <span slot="supporting-text">
              ${this.hass.localize("ui.panel.config.backup.encryption_key.change_encryption_key_description")}
            </span>
            <ha-button class="danger" slot="end" @click=${this._change}>
              ${this.hass.localize("ui.panel.config.backup.encryption_key.change_encryption_key_action")}
            </ha-button>
          </ha-md-list-item>
        </ha-md-list>
      `:n.dy`
      <ha-md-list>
        <ha-md-list-item>
          <span slot="headline">
            ${this.hass.localize("ui.panel.config.backup.encryption_key.set_encryption_key")}</span>
          <span slot="supporting-text">
            ${this.hass.localize("ui.panel.config.backup.encryption_key.set_encryption_key_description")}
          </span>
          <ha-button slot="end" @click=${this._set}>
            ${this.hass.localize("ui.panel.config.backup.encryption_key.set_encryption_key_action")}</ha-button>
        </ha-md-list-item>
      </ha-md-list>
    `}},{kind:"method",key:"_download",value:function(){this._value&&(0,d.VY)(this.hass,this._value)}},{kind:"method",key:"_show",value:function(){(0,h.i)(this,{currentKey:this._value})}},{kind:"method",key:"_change",value:function(){(0,c.k)(this,{currentKey:this._value,saveKey:a=>{(0,o.B)(this,"value-changed",{value:a})}})}},{kind:"method",key:"_set",value:function(){(0,l.S)(this,{saveKey:a=>{(0,o.B)(this,"value-changed",{value:a})}})}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`ha-md-list{background:0 0;--md-list-item-leading-space:0;--md-list-item-trailing-space:0}ha-md-list-item{--md-item-overflow:visible}.danger{--mdc-theme-primary:var(--error-color)}`}]}}),n.oi);e()}catch(a){e(a)}}))},42603:function(a,e,i){i.d(e,{k:()=>s});var t=i(36522);const n=()=>Promise.all([i.e("7442"),i.e("50437")]).then(i.bind(i,36943)),s=(a,e)=>new Promise((i=>{const s=e?.cancel,o=e?.submit;(0,t.B)(a,"show-dialog",{dialogTag:"ha-dialog-change-backup-encryption-key",dialogImport:n,dialogParams:{...e,cancel:()=>{i(!1),s&&s()},submit:a=>{i(a),o&&o(a)}}})}))},84941:function(a,e,i){i.d(e,{s:()=>n});var t=i(36522);const n=(a,e)=>{(0,t.B)(a,"show-dialog",{dialogTag:"dialog-local-backup-location",dialogImport:()=>i.e("33602").then(i.bind(i,74136)),dialogParams:e})}},7111:function(a,e,i){i.d(e,{S:()=>s});var t=i(36522);const n=()=>Promise.all([i.e("7442"),i.e("28501")]).then(i.bind(i,82023)),s=(a,e)=>new Promise((i=>{const s=e?.cancel,o=e?.submit;(0,t.B)(a,"show-dialog",{dialogTag:"ha-dialog-set-backup-encryption-key",dialogImport:n,dialogParams:{...e,cancel:()=>{i(!1),s&&s()},submit:a=>{i(a),o&&o(a)}}})}))},93913:function(a,e,i){i.d(e,{i:()=>s});var t=i(36522);const n=()=>Promise.all([i.e("7442"),i.e("99091")]).then(i.bind(i,70697)),s=(a,e)=>(0,t.B)(a,"show-dialog",{dialogTag:"ha-dialog-show-backup-encryption-key",dialogImport:n,dialogParams:e})},13310:function(a,e,i){i.a(a,(async function(a,t){try{i.r(e);var n=i(44249),s=i(72621),o=i(57243),c=i(15093),l=i(72344),d=i(36522),h=i(87707),u=i(22381),r=i(76320),p=(i(59826),i(34273),i(54977),i(23334),i(13928),i(7285),i(99426),i(34326),i(37583),i(26779)),g=(i(87979),i(68545)),_=(i(5131),i(4322)),k=i(6384),f=i(84941),b=i(73192),y=a([g,_,k,p]);[g,_,k,p]=y.then?(await y)():y;const v="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",m="M6,2H18A2,2 0 0,1 20,4V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V4A2,2 0 0,1 6,2M12,4A6,6 0 0,0 6,10C6,13.31 8.69,16 12.1,16L11.22,13.77C10.95,13.29 11.11,12.68 11.59,12.4L12.45,11.9C12.93,11.63 13.54,11.79 13.82,12.27L15.74,14.69C17.12,13.59 18,11.9 18,10A6,6 0 0,0 12,4M12,9A1,1 0 0,1 13,10A1,1 0 0,1 12,11A1,1 0 0,1 11,10A1,1 0 0,1 12,9M7,18A1,1 0 0,0 6,19A1,1 0 0,0 7,20A1,1 0 0,0 8,19A1,1 0 0,0 7,18M12.09,13.27L14.58,19.58L17.17,18.08L12.95,12.77L12.09,13.27Z",$="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z";(0,n.Z)([(0,c.Mo)("ha-config-backup-settings")],(function(a,e){class i extends e{constructor(...e){super(...e),a(this)}}return{F:i,d:[{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"cloudStatus",value:void 0},{kind:"field",decorators:[(0,c.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"agents",value:()=>[]},{kind:"field",decorators:[(0,c.SB)()],key:"_config",value:void 0},{kind:"method",key:"willUpdate",value:function(a){(0,s.Z)(i,"willUpdate",this,3)([a]),a.has("config")&&!this._config&&(this._config=this.config)}},{kind:"method",key:"connectedCallback",value:function(){(0,s.Z)(i,"connectedCallback",this,3)([]),this._scrollToSection(),this._config=this.config}},{kind:"method",key:"_scrollToSection",value:async function(){if("locations"===window.location.hash.substring(1)&&(0,l.p)(this.hass,"hassio")&&!this._config?.create_backup.include_all_addons&&this._config?.create_backup.include_addons?.length)return this.addEventListener("backup-addons-fetched",(async()=>{await(0,r.y)(),this._scrolltoHash()})),void setTimeout((()=>{this._clearHash()}),500);await(0,r.y)(),this._scrolltoHash()}},{kind:"method",key:"_scrolltoHash",value:function(){const a=window.location.hash.substring(1);if(a){const e=this.shadowRoot.getElementById(a);e?.scrollIntoView(),this._clearHash()}}},{kind:"method",key:"_clearHash",value:function(){history.replaceState(null,"",window.location.pathname)}},{kind:"method",key:"render",value:function(){if(!this._config)return o.Ld;const a=(0,l.p)(this.hass,"hassio");return o.dy`
      <hass-subpage back-path="/config/backup" .hass=${this.hass} .narrow=${this.narrow} .header=${this.hass.localize("ui.panel.config.backup.settings.header")}>
        ${a?o.dy`
              <ha-button-menu slot="toolbar-icon">
                <ha-icon-button slot="trigger" .label=${this.hass.localize("ui.common.menu")} .path=${v}></ha-icon-button>
                <ha-list-item graphic="icon" @request-selected=${this._changeLocalLocation}>
                  <ha-svg-icon slot="graphic" .path=${m}></ha-svg-icon>
                  ${this.hass.localize("ui.panel.config.backup.settings.menu.change_default_location")}
                </ha-list-item>
              </ha-button-menu>
            `:o.Ld}

        <div class="content">
          <ha-card id="schedule">
            <div class="card-header">
              ${this.hass.localize("ui.panel.config.backup.settings.schedule.title")}
            </div>
            <div class="card-content">
              <p>
                ${this.hass.localize("ui.panel.config.backup.settings.schedule.description")}
              </p>
              <ha-backup-config-schedule .hass=${this.hass} .value=${this._config} @value-changed=${this._scheduleConfigChanged}></ha-backup-config-schedule>
            </div>
          </ha-card>
          <ha-card id="data">
            <div class="card-header">
              ${this.hass.localize("ui.panel.config.backup.settings.data.title")}
            </div>
            <div class="card-content">
              <ha-backup-config-data .hass=${this.hass} .value=${this._dataConfig} @value-changed=${this._dataConfigChanged} force-home-assistant hide-addon-version></ha-backup-config-data>
            </div>
          </ha-card>

          <ha-card class="agents" id="locations">
            <div class="card-header">
              ${this.hass.localize("ui.panel.config.backup.settings.locations.title")}
            </div>
            <div class="card-content">
              <p>
                ${this.hass.localize("ui.panel.config.backup.settings.locations.description")}
              </p>
              <ha-backup-config-agents .hass=${this.hass} .value=${this._config.create_backup.agent_ids} .agentsConfig=${this._config.agents} .cloudStatus=${this.cloudStatus} .agents=${this.agents} @value-changed=${this._agentsConfigChanged} show-settings></ha-backup-config-agents>
              ${this._config.create_backup.agent_ids.length?o.Ld:o.dy`
                    <ha-alert alert-type="warning" .title=${this.hass.localize("ui.panel.config.backup.settings.locations.no_location")}>
                      ${this.hass.localize("ui.panel.config.backup.settings.locations.no_location_description")}
                    </ha-alert>
                    <br/>
                  `}
            </div>
            <div class="card-actions">
              <a href=${(0,b.R)(this.hass,"/integrations/#backup")} target="_blank" rel="noreferrer">
                <ha-button>
                  <ha-svg-icon slot="icon" .path=${$}></ha-svg-icon>
                  ${this.hass.localize("ui.panel.config.backup.settings.locations.more_locations")}
                </ha-button>
              </a>
              ${a?o.dy`<a href="/config/storage">
                    <ha-button>
                      ${this.hass.localize("ui.panel.config.backup.settings.locations.manage_network_storage")}
                    </ha-button>
                  </a>`:o.Ld}
            </div>
          </ha-card>
          <ha-card>
            <div class="card-header">
              ${this.hass.localize("ui.panel.config.backup.settings.encryption_key.title")}
            </div>
            <div class="card-content">
              <p>
                ${this.hass.localize("ui.panel.config.backup.settings.encryption_key.description")}
              </p>
              <ha-backup-config-encryption-key .hass=${this.hass} .value=${this._config.create_backup.password} @value-changed=${this._encryptionKeyChanged}></ha-backup-config-encryption-key>
            </div>
          </ha-card>
        </div>
      </hass-subpage>
    `}},{kind:"method",key:"_changeLocalLocation",value:async function(a){(0,h.Q)(a)&&(0,f.s)(this,{})}},{kind:"method",key:"_scheduleConfigChanged",value:function(a){const e=a.detail.value;this._config={...this._config,schedule:e.schedule,retention:e.retention},this._debounceSave()}},{kind:"get",key:"_dataConfig",value:function(){const{include_addons:a,include_all_addons:e,include_database:i,include_folders:t}=this._config.create_backup;return{include_homeassistant:!0,include_database:i,include_folders:t||void 0,include_all_addons:e,include_addons:a||void 0}}},{kind:"method",key:"_dataConfigChanged",value:function(a){const e=a.detail.value;this._config={...this._config,create_backup:{...this.config.create_backup,include_database:e.include_database,include_folders:e.include_folders||null,include_all_addons:e.include_all_addons,include_addons:e.include_addons||null}},this._debounceSave()}},{kind:"method",key:"_agentsConfigChanged",value:function(a){const e=a.detail.value;this._config={...this._config,create_backup:{...this._config.create_backup,agent_ids:e}},this._debounceSave()}},{kind:"method",key:"_encryptionKeyChanged",value:function(a){const e=a.detail.value;this._config={...this._config,create_backup:{...this._config.create_backup,password:e}},this._debounceSave()}},{kind:"field",key:"_debounceSave",value(){return(0,u.D)((()=>this._save()),500)}},{kind:"method",key:"_save",value:async function(){await(0,p._r)(this.hass,{create_backup:{agent_ids:this._config.create_backup.agent_ids,include_folders:this._config.create_backup.include_folders??[],include_database:this._config.create_backup.include_database,include_addons:this._config.create_backup.include_addons??[],include_all_addons:this._config.create_backup.include_all_addons,password:this._config.create_backup.password},retention:this._config.retention,schedule:this._config.schedule}),(0,d.B)(this,"ha-refresh-backup-config")}},{kind:"field",static:!0,key:"styles",value:()=>o.iv`ha-card{scroll-margin-top:16px}.content{padding:28px 20px 0;max-width:690px;margin:0 auto 24px;gap:24px;display:flex;flex-direction:column}.alert{--mdc-theme-primary:var(--error-color)}.card-header{padding-bottom:8px}.card-content{padding-bottom:0}a{text-decoration:none}`}]}}),o.oi);t()}catch(a){t(a)}}))}};
//# sourceMappingURL=62807.3f550938fcf28b0a.js.map