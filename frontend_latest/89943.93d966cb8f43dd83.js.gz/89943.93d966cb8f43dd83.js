export const __webpack_ids__=["89943"];export const __webpack_modules__={49976:function(e,t,i){i.d(t,{U:()=>a});const a=e=>e.stopPropagation()},34612:function(e,t,i){i.d(t,{b:()=>s,u:()=>n});i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814);var a=i(73850);const n=e=>e.include_domains.length+e.include_entities.length+e.exclude_domains.length+e.exclude_entities.length===0,s=(e,t,i,n)=>{const s=new Set(e),o=new Set(t),r=new Set(i),l=new Set(n),d=s.size>0||o.size>0,c=r.size>0||l.size>0;return d||c?d&&!c?e=>o.has(e)||s.has((0,a.M)(e)):!d&&c?e=>!l.has(e)&&!r.has((0,a.M)(e)):s.size?e=>s.has((0,a.M)(e))?!l.has(e):o.has(e):r.size?e=>r.has((0,a.M)(e))?o.has(e):!l.has(e):e=>o.has(e):()=>!0}},94369:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{u:()=>r});var n=i(16485),s=i(27486),o=e([n]);n=(o.then?(await o)():o)[0];const r=(e,t)=>{try{return l(t)?.of(e)??e}catch{return e}},l=(0,s.Z)((e=>new Intl.DisplayNames(e.language,{type:"language",fallback:"code"})));a()}catch(e){a(e)}}))},99426:function(e,t,i){i.r(t);var a=i(44249),n=i(57243),s=i(15093),o=i(35359),r=i(36522);i(23334),i(37583);const l={info:"M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",warning:"M12,2L1,21H23M12,6L19.53,19H4.47M11,10V14H13V10M11,16V18H13V16",error:"M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z",success:"M20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.76,4 13.5,4.11 14.2,4.31L15.77,2.74C14.61,2.26 13.34,2 12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z"};(0,a.Z)([(0,s.Mo)("ha-alert")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)()],key:"title",value:()=>""},{kind:"field",decorators:[(0,s.Cb)({attribute:"alert-type"})],key:"alertType",value:()=>"info"},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"dismissable",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"method",key:"render",value:function(){return n.dy`
      <div class="issue-type ${(0,o.$)({[this.alertType]:!0})}" role="alert">
        <div class="icon ${this.title?"":"no-title"}">
          <slot name="icon">
            <ha-svg-icon .path=${l[this.alertType]}></ha-svg-icon>
          </slot>
        </div>
        <div class=${(0,o.$)({content:!0,narrow:this.narrow})}>
          <div class="main-content">
            ${this.title?n.dy`<div class="title">${this.title}</div>`:n.Ld}
            <slot></slot>
          </div>
          <div class="action">
            <slot name="action">
              ${this.dismissable?n.dy`<ha-icon-button @click=${this._dismissClicked} label="Dismiss alert" .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}></ha-icon-button>`:n.Ld}
            </slot>
          </div>
        </div>
      </div>
    `}},{kind:"method",key:"_dismissClicked",value:function(){(0,r.B)(this,"alert-dismissed-clicked")}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.action,.icon{z-index:1}.issue-type{position:relative;padding:8px;display:flex}.issue-type::after{position:absolute;top:0;right:0;bottom:0;left:0;opacity:.12;pointer-events:none;content:"";border-radius:4px}.icon.no-title{align-self:center}.content{display:flex;justify-content:space-between;align-items:center;width:100%;text-align:var(--float-start)}.content.narrow{flex-direction:column;align-items:flex-end}.action{width:min-content;--mdc-theme-primary:var(--primary-text-color)}.main-content{overflow-wrap:anywhere;word-break:break-word;margin-left:8px;margin-right:0;margin-inline-start:8px;margin-inline-end:0}.title{margin-top:2px;font-weight:700}.action ha-icon-button,.action mwc-button{--mdc-theme-primary:var(--primary-text-color);--mdc-icon-button-size:36px}.issue-type.info>.icon{color:var(--info-color)}.issue-type.info::after{background-color:var(--info-color)}.issue-type.warning>.icon{color:var(--warning-color)}.issue-type.warning::after{background-color:var(--warning-color)}.issue-type.error>.icon{color:var(--error-color)}.issue-type.error::after{background-color:var(--error-color)}.issue-type.success>.icon{color:var(--success-color)}.issue-type.success::after{background-color:var(--success-color)}:host ::slotted(ul){margin:0;padding-inline-start:20px}`}]}}),n.oi)},34273:function(e,t,i){var a=i(44249),n=i(72621),s=(i(9359),i(31526),i(22997),i(57243)),o=i(15093),r=i(5111),l=i(76525);(0,a.Z)([(0,o.Mo)("ha-button-menu")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",key:l.gA,value:void 0},{kind:"field",decorators:[(0,o.Cb)()],key:"corner",value:()=>"BOTTOM_START"},{kind:"field",decorators:[(0,o.Cb)({attribute:"menu-corner"})],key:"menuCorner",value:()=>"START"},{kind:"field",decorators:[(0,o.Cb)({type:Number})],key:"x",value:()=>null},{kind:"field",decorators:[(0,o.Cb)({type:Number})],key:"y",value:()=>null},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"multi",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"activatable",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"fixed",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,attribute:"no-anchor"})],key:"noAnchor",value:()=>!1},{kind:"field",decorators:[(0,o.IO)("mwc-menu",!0)],key:"_menu",value:void 0},{kind:"get",key:"items",value:function(){return this._menu?.items}},{kind:"get",key:"selected",value:function(){return this._menu?.selected}},{kind:"method",key:"focus",value:function(){this._menu?.open?this._menu.focusItemAtIndex(0):this._triggerButton?.focus()}},{kind:"method",key:"render",value:function(){return s.dy`
      <div @click=${this._handleClick}>
        <slot name="trigger" @slotchange=${this._setTriggerAria}></slot>
      </div>
      <mwc-menu .corner=${this.corner} .menuCorner=${this.menuCorner} .fixed=${this.fixed} .multi=${this.multi} .activatable=${this.activatable} .y=${this.y} .x=${this.x}>
        <slot></slot>
      </mwc-menu>
    `}},{kind:"method",key:"firstUpdated",value:function(e){(0,n.Z)(i,"firstUpdated",this,3)([e]),"rtl"===r.E.document.dir&&this.updateComplete.then((()=>{this.querySelectorAll("mwc-list-item").forEach((e=>{const t=document.createElement("style");t.innerHTML="span.material-icons:first-of-type { margin-left: var(--mdc-list-item-graphic-margin, 32px) !important; margin-right: 0px !important;}",e.shadowRoot.appendChild(t)}))}))}},{kind:"method",key:"_handleClick",value:function(){this.disabled||(this._menu.anchor=this.noAnchor?null:this,this._menu.show())}},{kind:"get",key:"_triggerButton",value:function(){return this.querySelector('ha-icon-button[slot="trigger"], mwc-button[slot="trigger"]')}},{kind:"method",key:"_setTriggerAria",value:function(){this._triggerButton&&(this._triggerButton.ariaHasPopup="menu")}},{kind:"field",static:!0,key:"styles",value:()=>s.iv`:host{display:inline-block;position:relative}::slotted([disabled]){color:var(--disabled-text-color)}`}]}}),s.oi)},59826:function(e,t,i){var a=i(44249),n=i(31622),s=i(57243),o=i(15093),r=i(22344);(0,a.Z)([(0,o.Mo)("ha-button")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",static:!0,key:"styles",value:()=>[r.W,s.iv`::slotted([slot=icon]){margin-inline-start:0px;margin-inline-end:8px;direction:var(--direction);display:block}.mdc-button{height:var(--button-height,36px)}.trailing-icon{display:flex}.slot-container{overflow:var(--button-slot-container-overflow,visible)}:host([destructive]){--mdc-theme-primary:var(--error-color)}`]}]}}),n.Button)},54977:function(e,t,i){var a=i(44249),n=i(57243),s=i(15093);(0,a.Z)([(0,s.Mo)("ha-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)()],key:"header",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,reflect:!0})],key:"raised",value:()=>!1},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{background:var(--custom-background-color,var(--card-background-color,#fff));-webkit-backdrop-filter:var(--ha-card-backdrop-filter,none);backdrop-filter:var(--ha-card-backdrop-filter,none);box-shadow:var(--ha-card-box-shadow,none);box-sizing:border-box;border-radius:var(--ha-card-border-radius,16px);color:var(--primary-text-color);display:block;transition:.3s ease-out;position:relative}:host([raised]){border:none;box-shadow:var(--ha-card-box-shadow,0px 2px 1px -1px rgba(0,0,0,.2),0px 1px 1px 0px rgba(0,0,0,.14),0px 1px 3px 0px rgba(0,0,0,.12))}.card-header,:host ::slotted(.card-header){color:var(--ha-card-header-color,var(--primary-text-color));font-family:var(--ha-card-header-font-family, inherit);font-size:var(--ha-card-header-font-size, 24px);letter-spacing:-.012em;line-height:48px;padding:12px 16px 16px;display:block;margin-block-start:0px;margin-block-end:0px;font-weight:400}:host ::slotted(.card-content:not(:first-child)),slot:not(:first-child)::slotted(.card-content){padding-top:0px;margin-top:-8px}:host ::slotted(.card-content){padding:16px}:host ::slotted(.card-actions){border-top:1px solid var(--divider-color,#e8e8e8);padding:5px 16px}`},{kind:"method",key:"render",value:function(){return n.dy`
      ${this.header?n.dy`<h1 class="card-header">${this.header}</h1>`:n.Ld}
      <slot></slot>
    `}}]}}),n.oi)},7285:function(e,t,i){i.d(t,{M:()=>d});var a=i(44249),n=i(72621),s=i(65703),o=i(46289),r=i(57243),l=i(15093);let d=(0,a.Z)([(0,l.Mo)("ha-list-item")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"method",key:"renderRipple",value:function(){return this.noninteractive?"":(0,n.Z)(i,"renderRipple",this,3)([])}},{kind:"get",static:!0,key:"styles",value:function(){return[o.W,r.iv`:host{padding-left:var(--mdc-list-side-padding-left,var(--mdc-list-side-padding,20px));padding-inline-start:var(--mdc-list-side-padding-left,var(--mdc-list-side-padding,20px));padding-right:var(--mdc-list-side-padding-right,var(--mdc-list-side-padding,20px));padding-inline-end:var(--mdc-list-side-padding-right,var(--mdc-list-side-padding,20px))}:host([graphic=avatar]:not([twoLine])),:host([graphic=icon]:not([twoLine])){height:48px}span.material-icons:first-of-type{margin-inline-start:0px!important;margin-inline-end:var(--mdc-list-item-graphic-margin,16px)!important;direction:var(--direction)!important}span.material-icons:last-of-type{margin-inline-start:auto!important;margin-inline-end:0px!important;direction:var(--direction)!important}.mdc-deprecated-list-item__meta{display:var(--mdc-list-item-meta-display);align-items:center;flex-shrink:0}:host([graphic=icon]:not([twoline])) .mdc-deprecated-list-item__graphic{margin-inline-end:var(--mdc-list-item-graphic-margin,20px)!important}:host([multiline-secondary]){height:auto}:host([multiline-secondary]) .mdc-deprecated-list-item__text{padding:8px 0}:host([multiline-secondary]) .mdc-deprecated-list-item__secondary-text{text-overflow:initial;white-space:normal;overflow:auto;display:inline-block;margin-top:10px}:host([multiline-secondary]) .mdc-deprecated-list-item__primary-text{margin-top:10px}:host([multiline-secondary]) .mdc-deprecated-list-item__secondary-text::before{display:none}:host([multiline-secondary]) .mdc-deprecated-list-item__primary-text::before{display:none}:host([disabled]){color:var(--disabled-text-color)}:host([noninteractive]){pointer-events:unset}`,"rtl"===document.dir?r.iv`span.material-icons:first-of-type,span.material-icons:last-of-type{direction:rtl!important;--direction:rtl}`:r.iv``]}}]}}),s.K)},30509:function(e,t,i){var a=i(44249),n=i(57243),s=i(15093);(0,a.Z)([(0,s.Mo)("ha-settings-row")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({type:Boolean,reflect:!0})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,reflect:!0})],key:"slim",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,attribute:"three-line"})],key:"threeLine",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,attribute:"wrap-heading",reflect:!0})],key:"wrapHeading",value:()=>!1},{kind:"method",key:"render",value:function(){return n.dy`
      <div class="prefix-wrap">
        <slot name="prefix"></slot>
        <div class="body" ?two-line=${!this.threeLine} ?three-line=${this.threeLine}>
          <slot name="heading"></slot>
          <div class="secondary"><slot name="description"></slot></div>
        </div>
      </div>
      <div class="content"><slot></slot></div>
    `}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{display:flex;padding:0 16px;align-content:normal;align-self:auto;align-items:center}.body{padding-inline-start:0;padding:8px 16px 8px 0;padding-inline-end:16px;overflow:hidden;display:var(--layout-vertical_-_display,flex);flex-direction:var(--layout-vertical_-_flex-direction,column);justify-content:var(--layout-center-justified_-_justify-content,center);flex:var(--layout-flex_-_flex,1);flex-basis:var(--layout-flex_-_flex-basis,0.000000001px)}.body[three-line]{min-height:var(--paper-item-body-three-line-min-height,88px)}:host(:not([wrap-heading])) body>*{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.body>.secondary{display:block;padding-top:4px;font-family:var(
        --mdc-typography-body2-font-family,
        var(--mdc-typography-font-family, Roboto, sans-serif)
      );-webkit-font-smoothing:antialiased;font-size:var(--mdc-typography-body2-font-size, .875rem);font-weight:var(--mdc-typography-body2-font-weight,400);line-height:normal;color:var(--secondary-text-color)}.body[two-line]{min-height:calc(var(--paper-item-body-two-line-min-height,72px) - 16px);flex:1}.content{display:contents}:host(:not([narrow])) .content{display:var(--settings-row-content-display,flex);justify-content:flex-end;flex:1;padding:16px 0}.content ::slotted(*){width:var(--settings-row-content-width)}:host([narrow]){align-items:normal;flex-direction:column;border-top:1px solid var(--divider-color);padding-bottom:8px}::slotted(ha-switch){padding:16px 0}.secondary{white-space:normal}.prefix-wrap{display:var(--settings-row-prefix-display)}:host([narrow]) .prefix-wrap{display:flex;align-items:center}:host([slim]),:host([slim]) .content,:host([slim]) ::slotted(ha-switch){padding:0}:host([slim]) .body{min-height:0}`}]}}),n.oi)},17170:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t),i.d(t,{HaSpinner:()=>h});var n=i(44249),s=i(72621),o=i(97677),r=i(43580),l=i(57243),d=i(15093),c=e([o]);o=(c.then?(await c)():c)[0];let h=(0,n.Z)([(0,d.Mo)("ha-spinner")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,d.Cb)()],key:"size",value:void 0},{kind:"method",key:"updated",value:function(e){if((0,s.Z)(i,"updated",this,3)([e]),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}},{kind:"field",static:!0,key:"styles",value:()=>[r.Z,l.iv`:host{--indicator-color:var(
          --ha-spinner-indicator-color,
          var(--primary-color)
        );--track-color:var(--ha-spinner-divider-color, var(--divider-color));--track-width:4px;--speed:3.5s;font-size:var(--ha-spinner-size, 48px)}`]}]}}),o.Z);a()}catch(e){a(e)}}))},1888:function(e,t,i){var a=i(44249),n=i(72621),s=i(62523),o=i(83835),r=i(57243),l=i(15093),d=i(13560);(0,a.Z)([(0,l.Mo)("ha-switch")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)({type:Boolean})],key:"haptic",value:()=>!1},{kind:"method",key:"firstUpdated",value:function(){(0,n.Z)(i,"firstUpdated",this,3)([]),this.addEventListener("change",(()=>{this.haptic&&(0,d.j)("light")}))}},{kind:"field",static:!0,key:"styles",value:()=>[o.W,r.iv`:host{--mdc-theme-secondary:var(--switch-checked-color)}.mdc-switch.mdc-switch--checked .mdc-switch__thumb{background-color:var(--switch-checked-button-color);border-color:var(--switch-checked-button-color)}.mdc-switch.mdc-switch--checked .mdc-switch__track{background-color:var(--switch-checked-track-color);border-color:var(--switch-checked-track-color)}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb{background-color:var(--switch-unchecked-button-color);border-color:var(--switch-unchecked-button-color)}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__track{background-color:var(--switch-unchecked-track-color);border-color:var(--switch-unchecked-track-color)}`]}]}}),s.H)},83166:function(e,t,i){var a=i(44249),n=i(72621),s=i(1105),o=i(33990),r=i(57243),l=i(15093),d=i(5111);(0,a.Z)([(0,l.Mo)("ha-textfield")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)({type:Boolean})],key:"invalid",value:void 0},{kind:"field",decorators:[(0,l.Cb)({attribute:"error-message"})],key:"errorMessage",value:void 0},{kind:"field",decorators:[(0,l.Cb)({type:Boolean})],key:"icon",value:()=>!1},{kind:"field",decorators:[(0,l.Cb)({type:Boolean})],key:"iconTrailing",value:()=>!1},{kind:"field",decorators:[(0,l.Cb)()],key:"autocomplete",value:void 0},{kind:"field",decorators:[(0,l.Cb)()],key:"autocorrect",value:void 0},{kind:"field",decorators:[(0,l.Cb)({attribute:"input-spellcheck"})],key:"inputSpellcheck",value:void 0},{kind:"field",decorators:[(0,l.IO)("input")],key:"formElement",value:void 0},{kind:"method",key:"updated",value:function(e){(0,n.Z)(i,"updated",this,3)([e]),(e.has("invalid")||e.has("errorMessage"))&&(this.setCustomValidity(this.invalid?this.errorMessage||this.validationMessage||"Invalid":""),(this.invalid||this.validateOnInitialRender||e.has("invalid")&&void 0!==e.get("invalid"))&&this.reportValidity()),e.has("autocomplete")&&(this.autocomplete?this.formElement.setAttribute("autocomplete",this.autocomplete):this.formElement.removeAttribute("autocomplete")),e.has("autocorrect")&&(this.autocorrect?this.formElement.setAttribute("autocorrect",this.autocorrect):this.formElement.removeAttribute("autocorrect")),e.has("inputSpellcheck")&&(this.inputSpellcheck?this.formElement.setAttribute("spellcheck",this.inputSpellcheck):this.formElement.removeAttribute("spellcheck"))}},{kind:"method",key:"renderIcon",value:function(e,t=!1){const i=t?"trailing":"leading";return r.dy`
      <span class="mdc-text-field__icon mdc-text-field__icon--${i}" tabindex=${t?1:-1}>
        <slot name="${i}Icon"></slot>
      </span>
    `}},{kind:"field",static:!0,key:"styles",value:()=>[o.W,r.iv`.mdc-text-field__input{width:var(--ha-textfield-input-width,100%)}.mdc-text-field:not(.mdc-text-field--with-leading-icon){padding:var(--text-field-padding,0px 16px)}.mdc-text-field--with-leading-icon.mdc-text-field--with-trailing-icon,.mdc-text-field__affix--suffix{padding-right:var(--text-field-suffix-padding-right,0px);padding-inline-end:var(--text-field-suffix-padding-right,0px)}.mdc-text-field__affix--suffix{padding-left:var(--text-field-suffix-padding-left,12px);padding-inline-start:var(--text-field-suffix-padding-left,12px);direction:ltr}.mdc-text-field--with-leading-icon{padding-inline-start:var(--text-field-suffix-padding-left,0px);padding-inline-end:var(--text-field-suffix-padding-right,16px);direction:var(--direction)}.mdc-text-field--with-leading-icon.mdc-text-field--with-trailing-icon{padding-left:var(--text-field-suffix-padding-left,0px);padding-inline-start:var(--text-field-suffix-padding-left,0px)}.mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__affix--suffix,.mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__icon{color:var(--secondary-text-color)}.mdc-text-field__icon--leading{margin-inline-start:16px;margin-inline-end:8px;direction:var(--direction)}.mdc-text-field__icon--trailing{padding:var(--textfield-icon-trailing-padding,12px)}.mdc-floating-label:not(.mdc-floating-label--float-above){text-overflow:ellipsis;width:inherit;padding-right:30px;padding-inline-end:30px;padding-inline-start:initial;box-sizing:border-box;direction:var(--direction)}input{text-align:var(--text-field-text-align,start)}input[type=color]{height:20px}::-ms-reveal{display:none}:host([no-spinner]) input::-webkit-inner-spin-button,:host([no-spinner]) input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}input[type=color]::-webkit-color-swatch-wrapper{padding:0}:host([no-spinner]) input[type=number]{-moz-appearance:textfield}.mdc-text-field__ripple{overflow:hidden}.mdc-text-field{overflow:var(--text-field-overflow)}.mdc-floating-label{inset-inline-start:16px!important;inset-inline-end:initial!important;transform-origin:var(--float-start);direction:var(--direction);text-align:var(--float-start)}.mdc-text-field--with-leading-icon.mdc-text-field--filled .mdc-floating-label{max-width:calc(100% - 48px - var(--text-field-suffix-padding-left,0px));inset-inline-start:calc(48px + var(--text-field-suffix-padding-left,0px))!important;inset-inline-end:initial!important;direction:var(--direction)}.mdc-text-field__input[type=number]{direction:var(--direction)}.mdc-text-field__affix--prefix{padding-right:var(--text-field-prefix-padding-right,2px);padding-inline-end:var(--text-field-prefix-padding-right,2px);padding-inline-start:initial}.mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__affix--prefix{color:var(--mdc-text-field-label-ink-color)}#helper-text ha-markdown{display:inline-block}`,"rtl"===d.E.document.dir?r.iv`.mdc-floating-label,.mdc-text-field--with-leading-icon,.mdc-text-field--with-leading-icon.mdc-text-field--filled .mdc-floating-label,.mdc-text-field__icon--leading,.mdc-text-field__input[type=number]{direction:rtl;--direction:rtl}`:r.iv``]}]}}),s.P)},38495:function(e,t,i){i.d(t,{AI:()=>o,Dy:()=>g,GV:()=>p,I2:()=>n,PA:()=>d,SC:()=>l,Vg:()=>f,XT:()=>u,Xp:()=>s,_v:()=>r,af:()=>h,eP:()=>a,jZ:()=>c});const a=(e,t,i)=>"run-start"===t.type?e={init_options:i,stage:"ready",run:t.data,events:[t]}:e?((e="wake_word-start"===t.type?{...e,stage:"wake_word",wake_word:{...t.data,done:!1}}:"wake_word-end"===t.type?{...e,wake_word:{...e.wake_word,...t.data,done:!0}}:"stt-start"===t.type?{...e,stage:"stt",stt:{...t.data,done:!1}}:"stt-end"===t.type?{...e,stt:{...e.stt,...t.data,done:!0}}:"intent-start"===t.type?{...e,stage:"intent",intent:{...t.data,done:!1}}:"intent-end"===t.type?{...e,intent:{...e.intent,...t.data,done:!0}}:"tts-start"===t.type?{...e,stage:"tts",tts:{...t.data,done:!1}}:"tts-end"===t.type?{...e,tts:{...e.tts,...t.data,done:!0}}:"run-end"===t.type?{...e,stage:"done"}:"error"===t.type?{...e,stage:"error",error:t.data}:{...e}).events=[...e.events,t],e):void console.warn("Received unexpected event before receiving session",t),n=(e,t,i)=>{let n;const o=s(e,(e=>{n=a(n,e,i),"run-end"!==e.type&&"error"!==e.type||o.then((e=>e())),n&&t(n)}),i);return o},s=(e,t,i)=>e.connection.subscribeMessage(t,{...i,type:"assist_pipeline/run"}),o=(e,t)=>e.callWS({type:"assist_pipeline/pipeline_debug/list",pipeline_id:t}),r=(e,t,i)=>e.callWS({type:"assist_pipeline/pipeline_debug/get",pipeline_id:t,pipeline_run_id:i}),l=e=>e.callWS({type:"assist_pipeline/pipeline/list"}),d=(e,t)=>e.callWS({type:"assist_pipeline/pipeline/get",pipeline_id:t}),c=(e,t)=>e.callWS({type:"assist_pipeline/pipeline/create",...t}),h=(e,t,i)=>e.callWS({type:"assist_pipeline/pipeline/update",pipeline_id:t,...i}),p=(e,t)=>e.callWS({type:"assist_pipeline/pipeline/set_preferred",pipeline_id:t}),u=(e,t)=>e.callWS({type:"assist_pipeline/pipeline/delete",pipeline_id:t}),g=e=>e.callWS({type:"assist_pipeline/language/list"}),f=e=>e.callWS({type:"assist_pipeline/device/list"})},75375:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t);var n=i(44249),s=i(57243),o=i(15093),r=i(17170),l=(i(54202),i(43344),i(28008)),d=e([r]);r=(d.then?(await d)():d)[0];(0,n.Z)([(0,o.Mo)("hass-loading-screen")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,attribute:"no-toolbar"})],key:"noToolbar",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"rootnav",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)()],key:"message",value:void 0},{kind:"method",key:"render",value:function(){return s.dy`
      ${this.noToolbar?"":s.dy`<div class="toolbar">
            ${this.rootnav||history.state?.root?s.dy`
                  <ha-menu-button .hass=${this.hass} .narrow=${this.narrow}></ha-menu-button>
                `:s.dy`
                  <ha-icon-button-arrow-prev .hass=${this.hass} @click=${this._handleBack}></ha-icon-button-arrow-prev>
                `}
          </div>`}
      <div class="content">
        <ha-spinner></ha-spinner>
        ${this.message?s.dy`<div id="loading-text">${this.message}</div>`:s.Ld}
      </div>
    `}},{kind:"method",key:"_handleBack",value:function(){history.back()}},{kind:"get",static:!0,key:"styles",value:function(){return[l.Qx,s.iv`:host{display:block;height:100%;background-color:var(--primary-background-color)}.toolbar{display:flex;align-items:center;font-size:20px;height:var(--header-height);padding:8px 12px;pointer-events:none;background-color:var(--app-header-background-color);font-weight:400;color:var(--app-header-text-color,#fff);border-bottom:var(--app-header-border-bottom,none);box-sizing:border-box}@media (max-width:599px){.toolbar{padding:4px}}ha-icon-button-arrow-prev,ha-menu-button{pointer-events:auto}.content{height:calc(100% - var(--header-height));display:flex;flex-direction:column;align-items:center;justify-content:center}#loading-text{max-width:350px;margin-top:16px}`]}}]}}),s.oi);a()}catch(e){a(e)}}))},66320:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=i(72621),s=(i(9359),i(56475),i(1331),i(70104),i(2060),i(57243)),o=i(15093),r=i(27486),l=i(94369),d=(i(99426),i(59826),i(34273),i(54977),i(23334),i(7285),i(37583),i(1888),i(38495)),c=i(38034),h=i(76131),p=i(88238),u=i(73192),g=i(77834),f=i(91163),m=i(49976),v=i(73850),x=i(83523),y=e([l]);l=(y.then?(await y)():y)[0];const k="M14,12H10V10H14M14,16H10V14H14M20,8H17.19C16.74,7.22 16.12,6.55 15.37,6.04L17,4.41L15.59,3L13.42,5.17C12.96,5.06 12.5,5 12,5C11.5,5 11.04,5.06 10.59,5.17L8.41,3L7,4.41L8.62,6.04C7.88,6.55 7.26,7.22 6.81,8H4V10H6.09C6.04,10.33 6,10.66 6,11V12H4V14H6V15C6,15.34 6.04,15.67 6.09,16H4V18H6.81C7.85,19.79 9.78,21 12,21C14.22,21 16.15,19.79 17.19,18H20V16H17.91C17.96,15.67 18,15.34 18,15V14H20V12H18V11C18,10.66 17.96,10.33 17.91,10H20V8Z",_="M9,22A1,1 0 0,1 8,21V18H4A2,2 0 0,1 2,16V4C2,2.89 2.9,2 4,2H20A2,2 0 0,1 22,4V16A2,2 0 0,1 20,18H13.9L10.2,21.71C10,21.9 9.75,22 9.5,22V22H9M10,16V19.08L13.08,16H20V4H4V16H10M17,11H15V9H17V11M13,11H11V9H13V11M9,11H7V9H9V11Z",b="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",w="M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z",$="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",C="M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.45,13.97L5.82,21L12,17.27Z",z="M9,3V4H4V6H5V19A2,2 0 0,0 7,21H17A2,2 0 0,0 19,19V6H20V4H15V3H9M9,8H11V17H9V8M13,8H15V17H13V8Z";(0,a.Z)([(0,o.Mo)("assist-pref")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"exposedEntities",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"cloudStatus",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_pipelines",value:()=>[]},{kind:"field",decorators:[(0,o.SB)()],key:"_preferred",value:()=>null},{kind:"field",decorators:[(0,o.SB)()],key:"_pipelineEntitiesCount",value:()=>0},{kind:"field",decorators:[(0,o.SB)()],key:"_exposeNew",value:void 0},{kind:"method",key:"willUpdate",value:function(){this.hasUpdated||(0,c.Fk)(this.hass,"conversation").then((e=>{this._exposeNew=e.expose_new}))}},{kind:"method",key:"firstUpdated",value:function(e){(0,n.Z)(i,"firstUpdated",this,3)([e]),(0,d.SC)(this.hass).then((e=>{this._pipelines=e.pipelines,this._preferred=e.preferred_pipeline})),this._pipelineEntitiesCount=Object.values(this.hass.entities).filter((e=>"assist_satellite"===(0,v.M)(e.entity_id)&&"unavailable"!==this.hass.states[e.entity_id].state)).length}},{kind:"field",key:"_exposedEntitiesCount",value(){return(0,r.Z)((e=>Object.entries(e).filter((([e,t])=>t.conversation&&e in this.hass.states)).length))}},{kind:"method",key:"render",value:function(){return s.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <img alt="" src=${(0,p.X1)({domain:"assist_pipeline",type:"icon",darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer"/>Assist
        </h1>
        <div class="header-actions">
          <a href=${(0,u.R)(this.hass,"/docs/assist/")} target="_blank" rel="noreferrer noopener" class="icon-link">
            <ha-icon-button .label=${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.link_learn_how_it_works")} .path=${w}></ha-icon-button>
          </a>
        </div>
        <mwc-list>
          ${this._pipelines.map((e=>s.dy`
              <ha-list-item twoline hasMeta role="button" .id=${e.id} @click=${this._editPipeline}>
                <span>
                  ${e.name}
                  ${this._preferred===e.id?s.dy`<ha-svg-icon .path=${C}></ha-svg-icon>`:""}
                </span>
                <span slot="secondary">
                  ${(0,l.u)(e.language,this.hass.locale)}
                </span>
                <ha-button-menu fixed slot="meta" @click=${m.U}>
                  <ha-icon-button slot="trigger" .label=${this.hass.localize("ui.panel.lovelace.editor.menu.open")} .path=${b}></ha-icon-button>
                  <ha-list-item graphic="icon" .id=${e.id} @request-selected=${this._talkWithPipeline}>
                    ${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.start_conversation")}
                    <ha-svg-icon slot="graphic" .path=${_}></ha-svg-icon>
                  </ha-list-item>
                  <ha-list-item graphic="icon" .disabled=${this._preferred===e.id} .id=${e.id} @request-selected=${this._setPreferredPipeline}>
                    ${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.detail.set_as_preferred")}
                    <ha-svg-icon slot="graphic" .path=${C}></ha-svg-icon>
                  </ha-list-item>
                  <ha-list-item graphic="icon" .id=${e.id} @request-selected=${this._debugPipeline}>
                    ${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.detail.debug")}
                    <ha-svg-icon slot="graphic" .path=${k}></ha-svg-icon>
                  </ha-list-item>
                  <ha-list-item class="danger" graphic="icon" .id=${e.id} @request-selected=${this._deletePipeline}>
                    ${this.hass.localize("ui.common.delete")}
                    <ha-svg-icon slot="graphic" .path=${z}></ha-svg-icon>
                  </ha-list-item>
                </ha-button-menu>
              </ha-list-item>
            `))}
        </mwc-list>
        <ha-button @click=${this._addPipeline} class="add" outlined>
          ${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.add_assistant")}
          <ha-svg-icon slot="icon" .path=${$}></ha-svg-icon>
        </ha-button>
        <ha-settings-row>
          <span slot="heading">
            ${this.hass.localize("ui.panel.config.voice_assistants.expose.expose_new_entities")}
          </span>
          <span slot="description">
            ${this.hass.localize("ui.panel.config.voice_assistants.expose.expose_new_entities_info")}
          </span>
          <ha-switch .checked=${this._exposeNew} .disabled=${void 0===this._exposeNew} @change=${this._exposeNewToggleChanged}></ha-switch>
        </ha-settings-row>
        <div class="card-actions">
          <a href="/config/voice-assistants/expose?assistants=conversation&historyBack">
            <ha-button>
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.exposed_entities",{number:this.exposedEntities?this._exposedEntitiesCount(this.exposedEntities):0})}
            </ha-button>
          </a>
          ${this._pipelineEntitiesCount>0?s.dy`
                <a href="/config/voice-assistants/assist/devices">
                  <ha-button>
                    ${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.assist_devices",{number:this._pipelineEntitiesCount})}
                  </ha-button>
                </a>
              `:""}
        </div>
      </ha-card>
    `}},{kind:"method",key:"_exposeNewToggleChanged",value:async function(e){const t=e.target;if(void 0!==this._exposeNew&&this._exposeNew!==t.checked)try{await(0,c.fL)(this.hass,"conversation",t.checked)}catch(e){t.checked=!t.checked}}},{kind:"method",key:"_talkWithPipeline",value:function(e){const t=e.currentTarget.id;(0,f._)(this,this.hass,{pipeline_id:t})}},{kind:"method",key:"_setPreferredPipeline",value:async function(e){const t=e.currentTarget.id;await(0,d.GV)(this.hass,t),this._preferred=t}},{kind:"method",key:"_debugPipeline",value:async function(e){const t=e.currentTarget.id;(0,x.c)(`/config/voice-assistants/debug/${t}`)}},{kind:"method",key:"_deletePipeline",value:async function(e){const t=e.currentTarget.id;if(this._preferred===t)return void(0,h.showAlertDialog)(this,{text:this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.delete.error_preferred")});const i=this._pipelines.find((e=>e.id===t));await(0,h.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.delete.confirm_title",{name:i.name}),text:this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.delete.confirm_text",{name:i.name}),confirmText:this.hass.localize("ui.common.delete"),destructive:!0})&&(await(0,d.XT)(this.hass,i.id),this._pipelines=this._pipelines.filter((e=>e!==i)))}},{kind:"method",key:"_editPipeline",value:function(e){const t=e.currentTarget.id,i=this._pipelines.find((e=>e.id===t));this._openDialog(i)}},{kind:"method",key:"_addPipeline",value:function(){this._openDialog()}},{kind:"method",key:"_openDialog",value:async function(e){(0,g.t)(this,{cloudActiveSubscription:this.cloudStatus?.logged_in&&this.cloudStatus.active_subscription,pipeline:e,createPipeline:async e=>{const t=await(0,d.jZ)(this.hass,e);this._pipelines=this._pipelines.concat(t)},updatePipeline:async t=>{const i=await(0,d.af)(this.hass,e.id,t);this._pipelines=this._pipelines.map((t=>t===e?i:t))}})}},{kind:"field",static:!0,key:"styles",value:()=>s.iv`.card-actions,.card-header{display:flex}a{color:var(--primary-color)}.header-actions{position:absolute;right:0px;inset-inline-end:0px;inset-inline-start:initial;top:24px;display:flex;flex-direction:row}.header-actions .icon-link{margin-top:-16px;margin-right:8px;margin-inline-end:8px;margin-inline-start:initial;direction:var(--direction);color:var(--secondary-text-color)}ha-list-item{--mdc-list-item-meta-size:auto;--mdc-list-item-meta-display:flex;--mdc-list-side-padding-right:8px;--mdc-list-side-padding-left:16px}ha-list-item.danger{color:var(--error-color);border-top:1px solid var(--divider-color)}.card-actions a,ha-button-menu a{text-decoration:none}ha-svg-icon{color:currentColor;width:16px}.add{margin:0 16px 16px}.card-header{align-items:center;padding-bottom:0}img{height:28px;margin-right:16px;margin-inline-end:16px;margin-inline-start:initial}`}]}}),s.oi);t()}catch(e){t(e)}}))},58183:function(e,t,i){var a=i(44249),n=(i(9359),i(56475),i(31622),i(57243)),s=i(15093),o=i(27486),r=i(36522),l=i(34612),d=(i(99426),i(54977),i(30509),i(1888),i(94616)),c=i(38034),h=i(88238);let p=(0,a.Z)(null,(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"exposedEntities",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"cloudStatus",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_exposeNew",value:void 0},{kind:"field",key:"_exposedEntitiesCount",value(){return(0,o.Z)((e=>Object.entries(e).filter((([e,t])=>t["cloud.alexa"]&&e in this.hass.states)).length))}},{kind:"method",key:"willUpdate",value:function(){this.hasUpdated||(0,c.Fk)(this.hass,"cloud.alexa").then((e=>{this._exposeNew=e.expose_new}))}},{kind:"method",key:"render",value:function(){if(!this.cloudStatus)return n.Ld;const e=this.cloudStatus.alexa_registered,{alexa_enabled:t,alexa_report_state:i}=this.cloudStatus.prefs,a=!(0,l.u)(this.cloudStatus.alexa_entities);return n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <img alt="" src=${(0,h.X1)({domain:"alexa",type:"icon",darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer"/>${this.hass.localize("ui.panel.config.cloud.account.alexa.title")}
        </h1>
        <div class="header-actions">
          <a href="https://www.nabucasa.com/config/amazon_alexa/" target="_blank" rel="noreferrer" class="icon-link">
            <ha-icon-button .label=${this.hass.localize("ui.panel.config.cloud.account.alexa.link_learn_how_it_works")} .path=${"M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z"}></ha-icon-button>
          </a>
          <ha-switch .checked=${t} @change=${this._enabledToggleChanged}></ha-switch>
        </div>
        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.cloud.account.alexa.info")}
          </p>
          ${a?n.dy`<ha-alert alert-type="warning">
                ${this.hass.localize("ui.panel.config.cloud.account.alexa.manual_config")}
              </ha-alert>`:""}
          ${t?n.dy`${e?"":n.dy`<ha-alert .title=${this.hass.localize("ui.panel.config.cloud.account.alexa.not_configured_title")}>
                      ${this.hass.localize("ui.panel.config.cloud.account.alexa.not_configured_text")}

                      <ul>
                        <li>
                          <a href="https://skills-store.amazon.com/deeplink/dp/B0772J1QKB?deviceType=app" target="_blank" rel="noreferrer">
                            ${this.hass.localize("ui.panel.config.cloud.account.alexa.enable_ha_skill")}
                          </a>
                        </li>
                        <li>
                          <a href="https://www.nabucasa.com/config/amazon_alexa/" target="_blank" rel="noreferrer">
                            ${this.hass.localize("ui.panel.config.cloud.account.alexa.config_documentation")}
                          </a>
                        </li>
                      </ul>
                    </ha-alert>`}<ha-settings-row>
                  <span slot="heading">
                    ${this.hass.localize("ui.panel.config.cloud.account.alexa.expose_new_entities")}
                  </span>
                  <span slot="description">
                    ${this.hass.localize("ui.panel.config.cloud.account.alexa.expose_new_entities_info")}
                  </span>
                  <ha-switch .checked=${this._exposeNew} .disabled=${void 0===this._exposeNew} @change=${this._exposeNewToggleChanged}></ha-switch> </ha-settings-row>${e?n.dy`
                      <ha-settings-row>
                        <span slot="heading">
                          ${this.hass.localize("ui.panel.config.cloud.account.alexa.enable_state_reporting")}
                        </span>
                        <span slot="description">
                          ${this.hass.localize("ui.panel.config.cloud.account.alexa.info_state_reporting")}
                        </span>
                        <ha-switch .checked=${i} @change=${this._reportToggleChanged}></ha-switch>
                      </ha-settings-row>
                    `:""}`:""}
        </div>
        ${t?n.dy`<div class="card-actions">
              <a href="/config/voice-assistants/expose?assistants=cloud.alexa&historyBack">
                <mwc-button>
                  ${a?this.hass.localize("ui.panel.config.cloud.account.alexa.show_entities"):this.hass.localize("ui.panel.config.cloud.account.alexa.exposed_entities",{number:this.exposedEntities?this._exposedEntitiesCount(this.exposedEntities):0})}
                </mwc-button>
              </a>
            </div>`:n.Ld}
      </ha-card>
    `}},{kind:"method",key:"_exposeNewToggleChanged",value:async function(e){const t=e.target;if(void 0!==this._exposeNew&&this._exposeNew!==t.checked)try{await(0,c.fL)(this.hass,"cloud.alexa",t.checked)}catch(e){t.checked=!t.checked}}},{kind:"method",key:"_enabledToggleChanged",value:async function(e){const t=e.target;try{await(0,d.LV)(this.hass,{alexa_enabled:t.checked}),(0,r.B)(this,"ha-refresh-cloud-status")}catch(e){t.checked=!t.checked}}},{kind:"method",key:"_reportToggleChanged",value:async function(e){const t=e.target;try{await(0,d.LV)(this.hass,{alexa_report_state:t.checked}),(0,r.B)(this,"ha-refresh-cloud-status")}catch(e){alert(`${this.hass.localize("ui.panel.config.cloud.account.alexa.state_reporting_error",{enable_disable:this.hass.localize(t.checked?"ui.panel.config.cloud.account.alexa.enable":"ui.panel.config.cloud.account.alexa.disable")})} ${e.message}`),t.checked=!t.checked}}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.card-actions,.card-header{display:flex}a{color:var(--primary-color)}ha-settings-row{padding:0}.header-actions{position:absolute;right:24px;inset-inline-end:24px;inset-inline-start:initial;top:24px;display:flex;flex-direction:row}.header-actions .icon-link{margin-top:-16px;margin-right:8px;margin-inline-end:8px;margin-inline-start:initial;direction:var(--direction);color:var(--secondary-text-color)}.card-actions a{text-decoration:none}.card-header{align-items:center}img{height:28px;margin-right:16px;margin-inline-end:16px;margin-inline-start:initial}`}]}}),n.oi);customElements.define("cloud-alexa-pref",p)},1715:function(e,t,i){var a=i(44249),n=i(57243),s=i(15093),o=(i(54977),i(88238)),r=(i(37583),i(59826),i(72344));(0,a.Z)([(0,s.Mo)("cloud-discover")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"render",value:function(){return n.dy`
      <ha-card outlined>
        <div class="card-content">
          <h1 class="header">
            ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.title",{home_assistant_cloud:n.dy`
                  <span class="no-wrap">ASCIA Cloud</span>
                `})}
          </h1>
          <div class="features">
            <div class="feature">
              <div class="logos">
                <div class="round-icon">
                  <ha-svg-icon .path=${"M8,7A2,2 0 0,1 10,9V14A2,2 0 0,1 8,16A2,2 0 0,1 6,14V9A2,2 0 0,1 8,7M14,14C14,16.97 11.84,19.44 9,19.92V22H7V19.92C4.16,19.44 2,16.97 2,14H4A4,4 0 0,0 8,18A4,4 0 0,0 12,14H14M21.41,9.41L17.17,13.66L18.18,10H14A2,2 0 0,1 12,8V4A2,2 0 0,1 14,2H20A2,2 0 0,1 22,4V8C22,8.55 21.78,9.05 21.41,9.41Z"}></ha-svg-icon>
                </div>
              </div>
              <h2>
                ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.speech.title")}
                <span class="no-wrap"></span>
              </h2>
              <p>
                ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.speech.text")}
              </p>
            </div>
            <div class="feature">
              <div class="logos">
                <img alt="Google Assistant" src=${(0,o.X1)({domain:"google_assistant",type:"icon",darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer"/>
                <img alt="Amazon Alexa" src=${(0,o.X1)({domain:"alexa",type:"icon",darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer"/>
              </div>
              <h2>
                ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.assistants.title")}
              </h2>
              <p>
                ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.assistants.text")}
              </p>
            </div>
          </div>
          <div class="more">
            <a href="https://www.nabucasa.com" target="_blank" rel="noreferrer">
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.and_more")}
              <ha-svg-icon .path=${"M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z"}></ha-svg-icon>
            </a>
          </div>
        </div>
        ${(0,r.p)(this.hass,"cloud")?n.dy`
              <div class="card-actions">
                <a href="/config/cloud/register">
                  <ha-button unelevated>
                    ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.try_one_month")}
                  </ha-button>
                </a>
                <a href="/config/cloud/login">
                  <ha-button>
                    ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.sign_in")}
                  </ha-button>
                </a>
              </div>
            `:n.Ld}
      </ha-card>
    `}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.feature,.header{text-align:center}ha-card{display:flex;flex-direction:column}.card-content{padding:24px 16px}.card-actions{display:flex;justify-content:space-between}.header{font-weight:400;font-size:28px;line-height:36px;max-width:600px;margin:0 auto 8px}.feature,.feature .logos{margin-bottom:16px}@media (min-width:800px){.header{font-size:32px;line-height:40px;margin-bottom:16px}}.features{display:grid;grid-template-columns:auto;grid-gap:16px;padding:16px}@media (min-width:600px){.features{grid-template-columns:repeat(2,1fr)}}.feature{display:flex;flex-direction:column;align-items:center}.feature .logos>*{width:40px;height:40px;margin:0 4px}.round-icon{border-radius:50%;color:#6e41ab;background-color:#e8dcf7;display:flex;align-items:center;justify-content:center;font-size:24px}.feature h2{font-weight:500;font-size:16px;line-height:24px;margin-top:0;margin-bottom:8px}.feature p{font-weight:400;font-size:14px;line-height:20px;margin:0}.more{display:flex;align-items:center;justify-content:center}.more a{text-decoration:none;color:var(--primary-color);font-weight:500;font-size:14px}.more a ha-svg-icon{--mdc-icon-size:16px}.no-wrap{white-space:nowrap}`}]}}),n.oi)},81950:function(e,t,i){var a=i(44249),n=(i(9359),i(56475),i(31622),i(57243)),s=i(15093),o=i(27486),r=i(36522),l=i(34612),d=(i(99426),i(54977),i(30509),i(1888),i(83166),i(94616)),c=i(38034),h=i(88238),p=i(58885);let u=(0,a.Z)(null,(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"exposedEntities",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"cloudStatus",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_exposeNew",value:void 0},{kind:"method",key:"willUpdate",value:function(){this.hasUpdated||(0,c.Fk)(this.hass,"cloud.google_assistant").then((e=>{this._exposeNew=e.expose_new}))}},{kind:"field",key:"_exposedEntitiesCount",value(){return(0,o.Z)((e=>Object.entries(e).filter((([e,t])=>t["cloud.google_assistant"]&&e in this.hass.states)).length))}},{kind:"method",key:"render",value:function(){if(!this.cloudStatus)return n.Ld;const e=this.cloudStatus.google_registered,{google_enabled:t,google_report_state:i,google_secure_devices_pin:a}=this.cloudStatus.prefs,s=!(0,l.u)(this.cloudStatus.google_entities);return n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <img alt="" src=${(0,h.X1)({domain:"google_assistant",type:"icon",darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer"/>${this.hass.localize("ui.panel.config.cloud.account.google.title")}
        </h1>
        <div class="header-actions">
          <a href="https://www.nabucasa.com/config/google_assistant/" target="_blank" rel="noreferrer" class="icon-link">
            <ha-icon-button .label=${this.hass.localize("ui.panel.config.cloud.account.google.link_learn_how_it_works")} .path=${"M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z"}></ha-icon-button>
          </a>
          <ha-switch .checked=${t} @change=${this._enabledToggleChanged}></ha-switch>
        </div>
        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.cloud.account.google.info")}
          </p>
          ${s?n.dy`<ha-alert alert-type="warning">
                ${this.hass.localize("ui.panel.config.cloud.account.google.manual_config")}
              </ha-alert>`:""}
          ${t?n.dy`${e?"":n.dy`
                      <ha-alert .title=${this.hass.localize("ui.panel.config.cloud.account.google.not_configured_title")}>
                        ${this.hass.localize("ui.panel.config.cloud.account.google.not_configured_text")}

                        <ul>
                          <li>
                            <a href="https://assistant.google.com/services/a/uid/00000091fd5fb875?hl=en-US" target="_blank" rel="noreferrer">
                              ${this.hass.localize("ui.panel.config.cloud.account.google.enable_ha_skill")}
                            </a>
                          </li>
                          <li>
                            <a href="https://www.nabucasa.com/config/google_assistant/" target="_blank" rel="noreferrer">
                              ${this.hass.localize("ui.panel.config.cloud.account.google.config_documentation")}
                            </a>
                          </li>
                        </ul>
                      </ha-alert>
                    `}
                <ha-settings-row>
                  <span slot="heading">
                    ${this.hass.localize("ui.panel.config.cloud.account.google.expose_new_entities")}
                  </span>
                  <span slot="description">
                    ${this.hass.localize("ui.panel.config.cloud.account.google.expose_new_entities_info")}
                  </span>
                  <ha-switch .checked=${this._exposeNew} .disabled=${void 0===this._exposeNew} @change=${this._exposeNewToggleChanged}></ha-switch> </ha-settings-row>${e?n.dy`
                      ${this.cloudStatus.http_use_ssl?n.dy`
                            <ha-alert alert-type="warning" .title=${this.hass.localize("ui.panel.config.cloud.account.google.http_use_ssl_warning_title")}>
                              ${this.hass.localize("ui.panel.config.cloud.account.google.http_use_ssl_warning_text")}
                              <a href="https://www.nabucasa.com/config/google_assistant/#local-communication" target="_blank" rel="noreferrer">${this.hass.localize("ui.panel.config.common.learn_more")}</a>
                            </ha-alert>
                          `:""}

                      <ha-settings-row>
                        <span slot="heading">
                          ${this.hass.localize("ui.panel.config.cloud.account.google.enable_state_reporting")}
                        </span>
                        <span slot="description">
                          ${this.hass.localize("ui.panel.config.cloud.account.google.info_state_reporting")}
                        </span>
                        <ha-switch .checked=${i} @change=${this._reportToggleChanged}></ha-switch>
                      </ha-settings-row>

                      <ha-settings-row>
                        <span slot="heading">
                          ${this.hass.localize("ui.panel.config.cloud.account.google.security_devices")}
                        </span>
                        <span slot="description">
                          ${this.hass.localize("ui.panel.config.cloud.account.google.enter_pin_info")}
                        </span>
                      </ha-settings-row>

                      <ha-textfield id="google_secure_devices_pin" .label=${this.hass.localize("ui.panel.config.cloud.account.google.devices_pin")} .placeholder=${this.hass.localize("ui.panel.config.cloud.account.google.enter_pin_hint")} .value=${a||""} @change=${this._pinChanged}></ha-textfield>
                    `:""}`:""}
        </div>
        ${t?n.dy`<div class="card-actions">
              <a href="/config/voice-assistants/expose?assistants=cloud.google_assistant&historyBack">
                <mwc-button>
                  ${s?this.hass.localize("ui.panel.config.cloud.account.google.show_entities"):this.hass.localize("ui.panel.config.cloud.account.google.exposed_entities",{number:this.exposedEntities?this._exposedEntitiesCount(this.exposedEntities):0})}
                </mwc-button>
              </a>
            </div>`:n.Ld}
      </ha-card>
    `}},{kind:"method",key:"_exposeNewToggleChanged",value:async function(e){const t=e.target;if(void 0!==this._exposeNew&&this._exposeNew!==t.checked)try{await(0,c.fL)(this.hass,"cloud.google_assistant",t.checked)}catch(e){t.checked=!t.checked}}},{kind:"method",key:"_enabledToggleChanged",value:async function(e){const t=e.target;try{await(0,d.LV)(this.hass,{google_enabled:t.checked}),(0,r.B)(this,"ha-refresh-cloud-status")}catch(e){t.checked=!t.checked}}},{kind:"method",key:"_reportToggleChanged",value:async function(e){const t=e.target;try{await(0,d.LV)(this.hass,{google_report_state:t.checked}),(0,r.B)(this,"ha-refresh-cloud-status")}catch(e){alert(`Unable to ${t.checked?"enable":"disable"} report state. ${e.message}`),t.checked=!t.checked}}},{kind:"method",key:"_pinChanged",value:async function(e){const t=e.target;try{await(0,d.LV)(this.hass,{[t.id]:t.value||null}),(0,p.f)(this,this.hass),(0,r.B)(this,"ha-refresh-cloud-status")}catch(e){alert(`${this.hass.localize("ui.panel.config.cloud.account.google.enter_pin_error")} ${e.message}`),t.value=this.cloudStatus.prefs.google_secure_devices_pin||""}}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.card-actions,.card-header{display:flex}a{color:var(--primary-color)}.header-actions{position:absolute;right:24px;inset-inline-end:24px;inset-inline-start:initial;top:24px;display:flex;flex-direction:row}.header-actions .icon-link{margin-top:-16px;margin-right:8px;margin-inline-end:8px;margin-inline-start:initial;direction:var(--direction);color:var(--secondary-text-color)}ha-settings-row{padding:0}ha-textfield{width:250px;display:block;margin-top:8px}.card-actions a{text-decoration:none}.warning{color:var(--error-color)}.card-header{align-items:center}img{height:28px;margin-right:16px;margin-inline-end:16px;margin-inline-start:initial}`}]}}),n.oi);customElements.define("cloud-google-pref",u)},90710:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t),i.d(t,{HaConfigVoiceAssistantsAssistants:()=>p});var n=i(44249),s=i(57243),o=i(15093),r=i(72344),l=i(75375),d=(i(97546),i(66320)),c=(i(58183),i(1715),i(81950),i(8878)),h=e([l,d]);[l,d]=h.then?(await h)():h;let p=(0,n.Z)([(0,o.Mo)("ha-config-voice-assistants-assistants")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"cloudStatus",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"exposedEntities",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"route",value:void 0},{kind:"method",key:"render",value:function(){return this.hass?s.dy`
      <hass-tabs-subpage .hass=${this.hass} .narrow=${this.narrow} back-path="/config" .route=${this.route} .tabs=${c.voiceAssistantTabs}>
        <div class="content">
          ${(0,r.p)(this.hass,"assist_pipeline")?s.dy`
                <assist-pref .hass=${this.hass} .cloudStatus=${this.cloudStatus} .exposedEntities=${this.exposedEntities}></assist-pref>
              `:s.Ld}
          ${this.cloudStatus?.logged_in?s.dy`
                <cloud-alexa-pref .hass=${this.hass} .exposedEntities=${this.exposedEntities} .cloudStatus=${this.cloudStatus}></cloud-alexa-pref>
                <cloud-google-pref .hass=${this.hass} .exposedEntities=${this.exposedEntities} .cloudStatus=${this.cloudStatus}></cloud-google-pref>
              `:s.dy`<cloud-discover .hass=${this.hass}></cloud-discover>`}
        </div>
      </hass-tabs-subpage>
    `:s.dy`<hass-loading-screen></hass-loading-screen>`}},{kind:"field",static:!0,key:"styles",value:()=>s.iv`.content{padding:28px 20px 0;max-width:1040px;margin:0 auto}.content>*{display:block;margin:auto auto 24px;max-width:800px}a{text-decoration:none;color:inherit}`}]}}),s.oi);a()}catch(e){a(e)}}))},77834:function(e,t,i){i.d(t,{t:()=>s});var a=i(36522);const n=()=>Promise.all([i.e("83895"),i.e("8795"),i.e("67583"),i.e("45991"),i.e("44523")]).then(i.bind(i,55221)),s=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-voice-assistant-pipeline-detail",dialogImport:n,dialogParams:t})}},16485:function(e,t,i){i.a(e,(async function(e,t){try{i(92745);var a=i(61449),n=i(40574),s=i(30532),o=i(41674),r=i(49722),l=i(76632),d=i(7884),c=i(35185),h=i(60933),p=i(44180),u=i(49447);const e=async()=>{const e=(0,p.sS)(),t=[];(0,s.shouldPolyfill)()&&await Promise.all([i.e("80210"),i.e("74055")]).then(i.bind(i,98133)),(0,r.shouldPolyfill)()&&await Promise.all([i.e("83895"),i.e("75297"),i.e("80210"),i.e("60251")]).then(i.bind(i,59095)),(0,a.shouldPolyfill)(e)&&t.push(Promise.all([i.e("83895"),i.e("75297"),i.e("68250")]).then(i.bind(i,80561)).then((()=>(0,u.H)()))),(0,h.shouldPolyfill)()&&t.push(Promise.all([i.e("83895"),i.e("75297"),i.e("65578")]).then(i.bind(i,97995))),(0,n.shouldPolyfill)(e)&&t.push(Promise.all([i.e("83895"),i.e("75297"),i.e("59826")]).then(i.bind(i,31514))),(0,o.shouldPolyfill)(e)&&t.push(Promise.all([i.e("83895"),i.e("75297"),i.e("23649")]).then(i.bind(i,93840))),(0,l.shouldPolyfill)(e)&&t.push(Promise.all([i.e("83895"),i.e("75297"),i.e("42831")]).then(i.bind(i,29559))),(0,d.shouldPolyfill)(e)&&t.push(Promise.all([i.e("83895"),i.e("75297"),i.e("57377")]).then(i.bind(i,39030)).then((()=>i.e("61236").then(i.t.bind(i,4121,23))))),(0,c.shouldPolyfill)(e)&&t.push(Promise.all([i.e("83895"),i.e("75297"),i.e("13870")]).then(i.bind(i,74546))),0!==t.length&&await Promise.all(t).then((()=>(0,u.n)(e)))};await e(),t()}catch(e){t(e)}}),1)},88238:function(e,t,i){i.d(t,{RU:()=>n,X1:()=>a,u4:()=>s,zC:()=>o});const a=e=>`https://brands.home-assistant.io/${e.brand?"brands/":""}${e.useFallback?"_/":""}${e.domain}/${e.darkOptimized?"dark_":""}${e.type}.png`,n=e=>`https://brands.home-assistant.io/hardware/${e.category}/${e.darkOptimized?"dark_":""}${e.manufacturer}${e.model?`_${e.model}`:""}.png`,s=e=>e.split("/")[4],o=e=>e.startsWith("https://brands.home-assistant.io/")},73192:function(e,t,i){i.d(t,{R:()=>a});const a=(e,t)=>`https://${e.config.version.includes("b")?"rc":e.config.version.includes("dev")?"next":"www"}.home-assistant.io${t}`},58885:function(e,t,i){i.d(t,{f:()=>n});var a=i(72473);const n=(e,t)=>(0,a.C)(e,{message:t.localize("ui.common.successfully_saved")})}};
//# sourceMappingURL=89943.93d966cb8f43dd83.js.map