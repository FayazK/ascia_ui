export const __webpack_ids__=["19956"];export const __webpack_modules__={50875:function(e,t,i){i.d(t,{Eu:()=>o,hZ:()=>r,o9:()=>l});var a=i(27486),n=i(11259);const s=["#4269d0","#f4bd4a","#ff725c","#6cc5b0","#a463f2","#ff8ab7","#9c6b4e","#97bbf5","#01ab63","#9498a0","#094bad","#c99000","#d84f3e","#49a28f","#048732","#d96895","#8043ce","#7599d1","#7a4c31","#74787f","#6989f4","#ffd444","#ff957c","#8fe9d3","#62cc71","#ffadda","#c884ff","#badeff","#bf8b6d","#b6bac2","#927acc","#97ee3f","#bf3947","#9f5b00","#f48758","#8caed6","#f2b94f","#eff26e","#e43872","#d9b100","#9d7a00","#698cff","#d9d9d9","#00d27e","#d06800","#009f82","#c49200","#cbe8ff","#fecddf","#c27eb6","#8cd2ce","#c4b8d9","#f883b0","#a49100","#f48800","#27d0df","#a04a9b"];function o(e){return s[e%s.length]}function r(e,t){const i=t.getPropertyValue(`--graph-color-${e+1}`)||o(e);return(0,n.Rq)(i)}const l=(0,a.Z)((e=>s.map(((t,i)=>r(i,e)))),((e,t)=>e[0].getPropertyValue("--graph-color-1")===t[0].getPropertyValue("--graph-color-1")))},94947:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{G:()=>d});var n=i(16485),s=i(27486),o=i(27046),r=e([n,o]);[n,o]=r.then?(await r)():r;const l=(0,s.Z)((e=>new Intl.RelativeTimeFormat(e.language,{numeric:"auto"}))),d=(e,t,i,a=!0)=>{const n=(0,o.W)(e,i,t);return a?l(t).format(n.value,n.unit):Intl.NumberFormat(t.language,{style:"unit",unit:n.unit,unitDisplay:"long"}).format(Math.abs(n.value))};a()}catch(e){a(e)}}))},12753:function(e,t,i){i.d(t,{N:()=>n});const a=[" ",": "],n=(e,t)=>{const i=e.toLowerCase();for(const n of a){const a=`${t}${n}`;if(i.startsWith(a)){const t=e.substring(a.length);if(t.length)return s(t.substr(0,t.indexOf(" ")))?t:t[0].toUpperCase()+t.slice(1)}}},s=e=>e.toLowerCase()!==e},76002:function(e,t,i){i.d(t,{Q:()=>a});const a=e=>e.replace(/^_*(.)|_+(.)/g,((e,t,i)=>t?t.toUpperCase():" "+i.toUpperCase()))},27046:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{W:()=>h});var n=i(13809),s=i(29558),o=i(94763),r=i(19631);const l=1e3,d=60,c=60*d;function h(e,t=Date.now(),i,a={}){const h={...u,...a||{}},f=(+e-+t)/l;if(Math.abs(f)<h.second)return{value:Math.round(f),unit:"second"};const v=f/d;if(Math.abs(v)<h.minute)return{value:Math.round(v),unit:"minute"};const m=f/c;if(Math.abs(m)<h.hour)return{value:Math.round(m),unit:"hour"};const p=new Date(e),g=new Date(t);p.setHours(0,0,0,0),g.setHours(0,0,0,0);const y=(0,n.j)(p,g);if(0===y)return{value:Math.round(m),unit:"hour"};if(Math.abs(y)<h.day)return{value:y,unit:"day"};const _=(0,r.Bt)(i),b=(0,s.z)(p,{weekStartsOn:_}),k=(0,s.z)(g,{weekStartsOn:_}),w=(0,o.p)(b,k);if(0===w)return{value:y,unit:"day"};if(Math.abs(w)<h.week)return{value:w,unit:"week"};const $=p.getFullYear()-g.getFullYear(),x=12*$+p.getMonth()-g.getMonth();return 0===x?{value:w,unit:"week"}:Math.abs(x)<h.month||0===$?{value:x,unit:"month"}:{value:Math.round($),unit:"year"}}const u={second:45,minute:45,hour:22,day:5,week:4,month:11};a()}catch(f){a(f)}}))},44925:function(e,t,i){var a=i(44249),n=i(57243),s=i(15093),o=i(28816);i(65981);(0,a.Z)([(0,s.Mo)("ha-battery-icon")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"batteryStateObj",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"batteryChargingStateObj",value:void 0},{kind:"method",key:"render",value:function(){return this.batteryStateObj?n.dy`
      <ha-icon .icon=${(0,o.U)(this.batteryStateObj.state,"on"===this.batteryChargingStateObj?.state)}></ha-icon>
    `:n.Ld}}]}}),n.oi)},20130:function(e,t,i){var a=i(44249),n=i(72621),s=i(39785),o=i(52876),r=i(15093),l=i(57243),d=i(5111);(0,a.Z)([(0,r.Mo)("ha-fab")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"method",key:"firstUpdated",value:function(e){(0,n.Z)(i,"firstUpdated",this,3)([e]),this.style.setProperty("--mdc-theme-secondary","var(--primary-color)")}},{kind:"field",static:!0,key:"styles",value:()=>[o.W,l.iv`:host .mdc-fab--extended .mdc-fab__icon{margin-inline-start:-8px;margin-inline-end:12px;direction:var(--direction)}:disabled{--mdc-theme-secondary:var(--disabled-text-color);pointer-events:none}`,"rtl"===d.E.document.dir?l.iv`:host .mdc-fab--extended .mdc-fab__icon{direction:rtl}`:l.iv``]}]}}),s._)},13928:function(e,t,i){i.r(t),i.d(t,{HaIconNext:()=>r});var a=i(44249),n=i(15093),s=i(5111),o=i(37583);let r=(0,a.Z)([(0,n.Mo)("ha-icon-next")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,n.Cb)()],key:"path",value:()=>"rtl"===s.E.document.dir?"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z":"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"}]}}),o.HaSvgIcon)},41927:function(e,t,i){i.d(t,{Bg:()=>h,DT:()=>c,SY:()=>l,aJ:()=>o,cz:()=>r,ko:()=>d});var a=i(75278),n=i(96194);let s=function(e){return e[e.ANNOUNCE=1]="ANNOUNCE",e}({});const o=(e,t,i)=>e.connection.subscribeMessage(i,{type:"assist_satellite/intercept_wake_word",entity_id:t}),r=(e,t)=>e.callWS({type:"assist_satellite/test_connection",entity_id:t}),l=(e,t,i)=>e.callService("assist_satellite","announce",{message:i},{entity_id:t}),d=(e,t)=>e.callWS({type:"assist_satellite/get_configuration",entity_id:t}),c=(e,t,i)=>e.callWS({type:"assist_satellite/set_wake_words",entity_id:t,wake_word_ids:i}),h=e=>e&&e.state!==n.nZ&&(0,a.e)(e,s.ANNOUNCE)},43546:function(e,t,i){i.d(t,{Cp:()=>o,TZ:()=>r,W2:()=>s,YY:()=>d,iI:()=>n,j2:()=>l,oT:()=>a});i(9359),i(70104);const a=e=>e.map((e=>{if("string"!==e.type)return e;switch(e.name){case"username":return{...e,autocomplete:"username",autofocus:!0};case"password":return{...e,autocomplete:"current-password"};case"code":return{...e,autocomplete:"one-time-code",autofocus:!0};default:return e}})),n=(e,t)=>e.callWS({type:"auth/sign_path",path:t}),s=async(e,t,i,a)=>e.callWS({type:"config/auth_provider/homeassistant/create",user_id:t,username:i,password:a}),o=(e,t,i)=>e.callWS({type:"config/auth_provider/homeassistant/change_password",current_password:t,new_password:i}),r=(e,t,i)=>e.callWS({type:"config/auth_provider/homeassistant/admin_change_password",user_id:t,password:i}),l=(e,t,i)=>e.callWS({type:"config/auth_provider/homeassistant/admin_change_username",user_id:t,username:i}),d=(e,t,i)=>e.callWS({type:"auth/delete_all_refresh_tokens",token_type:t,delete_current_token:i})},12068:function(e,t,i){i.d(t,{B:()=>a,l:()=>n});i(9359),i(31526),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814);const a=e=>{const t={};return Object.entries(e).forEach((([e,i])=>{t[e]={value:i.value,items:i.items instanceof Set?Array.from(i.items):i.items}})),t},n=e=>{const t={};return Object.entries(e).forEach((([e,i])=>{t[e]={value:i.value,items:Array.isArray(i.items)?new Set(i.items):i.items}})),t}},6823:function(e,t,i){i.d(t,{ZK:()=>o,iP:()=>s,lf:()=>n,pD:()=>a});const a=e=>e.callWS({type:"diagnostics/list"}),n=(e,t)=>e.callWS({type:"diagnostics/get",domain:t}),s=e=>`/api/diagnostics/config_entry/${e}`,o=(e,t)=>`/api/diagnostics/config_entry/${e}/device/${t}`},48977:function(e,t,i){function a(e){return"strategy"in e}i.d(t,{Oh:()=>s,Q2:()=>n,Tx:()=>a,vj:()=>o});const n=(e,t,i)=>e.sendMessagePromise({type:"lovelace/config",url_path:t,force:i}),s=(e,t,i)=>e.callWS({type:"lovelace/config/save",url_path:t,config:i}),o=(e,t)=>e.callWS({type:"lovelace/config/delete",url_path:t})},6649:function(e,t,i){i.d(t,{JR:()=>n,Y:()=>s,iM:()=>o,j2:()=>a});const a=e=>e.callWS({type:"lovelace/dashboards/list"}),n=(e,t)=>e.callWS({type:"lovelace/dashboards/create",...t}),s=(e,t,i)=>e.callWS({type:"lovelace/dashboards/update",dashboard_id:t,...i}),o=(e,t)=>e.callWS({type:"lovelace/dashboards/delete",dashboard_id:t})},21168:function(e,t,i){i.d(t,{k:()=>s});var a=i(36522);const n=()=>Promise.all([i.e("91552"),i.e("78456"),i.e("24199"),i.e("27506"),i.e("41258"),i.e("56898"),i.e("35671"),i.e("42950"),i.e("65505"),i.e("5080"),i.e("90994"),i.e("53523"),i.e("18865"),i.e("27090"),i.e("90507"),i.e("16912"),i.e("97003")]).then(i.bind(i,42474)),s=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"ha-voice-assistant-setup-dialog",dialogImport:n,dialogParams:t})}},34515:function(e,t,i){i.r(t);var a=i(44249),n=(i(31622),i(57243)),s=i(15093);i(54202),i(43344),i(99426);(0,a.Z)([(0,s.Mo)("hass-error-screen")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"toolbar",value:()=>!0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"rootnav",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)()],key:"error",value:void 0},{kind:"method",key:"render",value:function(){return n.dy`
      ${this.toolbar?n.dy`<div class="toolbar">
            ${this.rootnav||history.state?.root?n.dy`
                  <ha-menu-button .hass=${this.hass} .narrow=${this.narrow}></ha-menu-button>
                `:n.dy`
                  <ha-icon-button-arrow-prev .hass=${this.hass} @click=${this._handleBack}></ha-icon-button-arrow-prev>
                `}
          </div>`:""}
      <div class="content">
        <ha-alert alert-type="error">${this.error}</ha-alert>
        <slot>
          <mwc-button @click=${this._handleBack}>
            ${this.hass?.localize("ui.common.back")}
          </mwc-button>
        </slot>
      </div>
    `}},{kind:"method",key:"_handleBack",value:function(){history.back()}},{kind:"get",static:!0,key:"styles",value:function(){return[n.iv`:host{display:block;height:100%;background-color:var(--primary-background-color)}.content,.toolbar{display:flex;box-sizing:border-box}.toolbar{align-items:center;font-size:20px;height:var(--header-height);padding:8px 12px;pointer-events:none;background-color:var(--app-header-background-color);font-weight:400;color:var(--app-header-text-color,#fff);border-bottom:var(--app-header-border-bottom,none)}@media (max-width:599px){.toolbar{padding:4px}}ha-icon-button-arrow-prev{pointer-events:auto}.content{color:var(--primary-text-color);height:calc(100% - var(--header-height));padding:16px;align-items:center;justify-content:center;flex-direction:column}a{color:var(--primary-color)}ha-alert{margin-bottom:16px}`]}}]}}),n.oi)},87979:function(e,t,i){var a=i(44249),n=i(57243),s=i(15093),o=i(31146),r=(i(54202),i(43344),i(28008));(0,a.Z)([(0,s.Mo)("hass-subpage")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)()],key:"header",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,attribute:"main-page"})],key:"mainPage",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:String,attribute:"back-path"})],key:"backPath",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"backCallback",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,reflect:!0})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"supervisor",value:()=>!1},{kind:"field",decorators:[(0,o.i)(".content")],key:"_savedScrollPos",value:void 0},{kind:"method",key:"render",value:function(){return n.dy`
      <div class="toolbar">
        ${this.mainPage||history.state?.root?n.dy`
              <ha-menu-button .hassio=${this.supervisor} .hass=${this.hass} .narrow=${this.narrow}></ha-menu-button>
            `:this.backPath?n.dy`
                <a href=${this.backPath}>
                  <ha-icon-button-arrow-prev .hass=${this.hass}></ha-icon-button-arrow-prev>
                </a>
              `:n.dy`
                <ha-icon-button-arrow-prev .hass=${this.hass} @click=${this._backTapped}></ha-icon-button-arrow-prev>
              `}

        <div class="main-title"><slot name="header">${this.header}</slot></div>
        <slot name="toolbar-icon"></slot>
      </div>
      <div class="content ha-scrollbar" @scroll=${this._saveScrollPos}>
        <slot></slot>
      </div>
      <div id="fab">
        <slot name="fab"></slot>
      </div>
    `}},{kind:"method",decorators:[(0,s.hO)({passive:!0})],key:"_saveScrollPos",value:function(e){this._savedScrollPos=e.target.scrollTop}},{kind:"method",key:"_backTapped",value:function(){this.backCallback?this.backCallback():history.back()}},{kind:"get",static:!0,key:"styles",value:function(){return[r.$c,n.iv`#fab,#fab[is-wide]{inset-inline-start:initial}:host{display:block;height:100%;background-color:var(--primary-background-color);overflow:hidden;position:relative}:host([narrow]){width:100%;position:fixed}.toolbar{display:flex;align-items:center;font-size:20px;height:var(--header-height);padding:8px 12px;background-color:var(--app-header-background-color);font-weight:400;color:var(--app-header-text-color,#fff);border-bottom:var(--app-header-border-bottom,none);box-sizing:border-box}@media (max-width:599px){.toolbar{padding:4px}}.toolbar a{color:var(--sidebar-text-color);text-decoration:none}::slotted([slot=toolbar-icon]),ha-icon-button-arrow-prev,ha-menu-button{pointer-events:auto;color:var(--sidebar-icon-color)}.main-title{margin:var(--margin-title);line-height:20px;min-width:0;flex-grow:1;overflow-wrap:break-word;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;padding-bottom:1px}.content{position:relative;width:100%;height:calc(100% - 1px - var(--header-height));overflow-y:auto;overflow:auto;-webkit-overflow-scrolling:touch}#fab{position:absolute;right:calc(16px + env(safe-area-inset-right));inset-inline-end:calc(16px + env(safe-area-inset-right));bottom:calc(16px + env(safe-area-inset-bottom));z-index:1;display:flex;flex-wrap:wrap;justify-content:flex-end;gap:8px}:host([narrow]) #fab.tabs{bottom:calc(84px + env(safe-area-inset-bottom))}#fab[is-wide]{bottom:24px;right:24px;inset-inline-end:24px}`]}}]}}),n.oi)},59360:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=(i(92745),i(9359),i(56475),i(31526),i(70104),i(2060),i(57243)),s=i(15093),o=i(35359),r=i(94571),l=i(47194),d=i(12753),c=(i(54977),i(65981),i(7285),i(63318)),h=i(45729),u=i(12939),f=i(46542),v=i(69615),m=i(20526),p=e([f,h]);[f,h]=p.then?(await p)():p;(0,a.Z)([(0,s.Mo)("ha-device-entities-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)()],key:"header",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"deviceName",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"entities",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:"show-hidden",type:Boolean})],key:"showHidden",value:()=>!1},{kind:"field",decorators:[(0,s.SB)()],key:"_extDisabledEntityEntries",value:void 0},{kind:"field",key:"_entityRows",value:()=>[]},{kind:"method",key:"shouldUpdate",value:function(e){return e.has("hass")&&1===e.size?(this._entityRows.forEach((e=>{e.hass=this.hass})),!1):(this._entityRows=[],!0)}},{kind:"method",key:"render",value:function(){if(!this.entities.length)return n.dy`
        <ha-card outlined .header=${this.header}>
          <div class="empty card-content">
            ${this.hass.localize("ui.panel.config.devices.entities.none")}
          </div>
        </ha-card>
      `;const e=[],t=[];return this.entities.forEach((i=>{i.disabled_by?this._extDisabledEntityEntries?t.push(this._extDisabledEntityEntries[i.entity_id]||i):t.push(i):e.push(i)})),n.dy`
      <ha-card outlined .header=${this.header}>
        ${e.length?n.dy`
              <div id="entities" class="move-up">
                <mwc-list>
                  ${e.map((e=>this.hass.states[e.entity_id]?this._renderEntity(e):this._renderEntry(e)))}
                </mwc-list>
              </div>
            `:n.Ld}
        ${t.length?n.dy`<div class=${(0,o.$)({"move-up":!e.length})}>
              ${this.showHidden?n.dy`
                    <mwc-list>
                      ${t.map((e=>this._renderEntry(e)))}
                    </mwc-list>
                    <button class="show-more" @click=${this._toggleShowHidden}>
                      ${this.hass.localize("ui.panel.config.devices.entities.show_less")}
                    </button>
                  `:n.dy`
                    <button class="show-more" @click=${this._toggleShowHidden}>
                      ${this.hass.localize("ui.panel.config.devices.entities.disabled_entities",{count:t.length})}
                    </button>
                  `}
            </div>`:n.Ld}
        <div class="card-actions">
          <mwc-button @click=${this._addToLovelaceView}>
            ${this.hass.localize("ui.panel.config.devices.entities.add_entities_lovelace")}
          </mwc-button>
        </div>
      </ha-card>
    `}},{kind:"method",key:"_toggleShowHidden",value:function(){if(this.showHidden=!this.showHidden,!this.showHidden||void 0!==this._extDisabledEntityEntries)return;this._extDisabledEntityEntries={};const e=this.entities.filter((e=>e.disabled_by)),t=async()=>{if(0===e.length)return;const i=e.pop().entity_id,a=await(0,c.L3)(this.hass,i);this._extDisabledEntityEntries[i]=a,this.requestUpdate("_extDisabledEntityEntries"),t()};t(),t(),t()}},{kind:"method",key:"_renderEntity",value:function(e){const t={entity:e.entity_id},i=(0,f.m)(t);if(this.hass){i.hass=this.hass;const a=this.hass.states[e.entity_id];let n=e.name?(0,d.N)(e.name,this.deviceName.toLowerCase()):e.has_entity_name?e.original_name||this.deviceName:(0,d.N)((0,l.C)(a),this.deviceName.toLowerCase());n||(n=(0,l.C)(a)),e.hidden_by&&(n+=` (${this.hass.localize("ui.panel.config.devices.entities.hidden")})`),t.name=n}return i.entry=e,this._entityRows.push(i),n.dy` <div>${i}</div> `}},{kind:"method",key:"_renderEntry",value:function(e){const t=e.stateName||e.name||e.original_name,i=(0,r.C)((0,h.xA)(this.hass,e));return n.dy`
      <ha-list-item graphic="icon" class="disabled-entry" .entry=${e} @click=${this._openEditEntry}>
        <ha-icon slot="graphic" .icon=${i}></ha-icon>
        <div class="name">
          ${t?(0,d.N)(t,this.deviceName.toLowerCase())||t:e.entity_id}
        </div>
      </ha-list-item>
    `}},{kind:"method",key:"_openEditEntry",value:function(e){const t=e.currentTarget.entry;(0,u.A)(this,{entityId:t.entity_id})}},{kind:"method",key:"_addToLovelaceView",value:function(){const e=this.entities.filter((e=>!e.disabled_by)).map((e=>e.entity_id));(0,v.$)(this,this.hass,(0,m.VG)(this.hass.states,e,{title:this.deviceName}),(0,m.lY)(e,{title:this.deviceName}),e)}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{display:block}ha-icon{margin-left:-8px}.disabled-entry,.entity-id{color:var(--secondary-text-color)}.buttons{text-align:right;margin:0 0 0 8px}.move-up{margin-top:-13px}.move-up:has(> mwc-list){margin-top:-24px}:not(.move-up)>mwc-list{margin-top:-24px}.move-up+:not(:has(mwc-list))>button.show-more,mwc-list+button.show-more{margin-top:-12px}#entities>mwc-list{margin:0 16px 0 8px}#entities>paper-icon-item{margin:0}paper-icon-item{min-height:40px;padding:0 16px;cursor:pointer;--paper-item-icon-width:48px}.name{font-size:14px}.name:dir(rtl){margin-inline-start:8px}.empty{text-align:center}button.show-more{color:var(--primary-color);text-align:left;cursor:pointer;background:0 0;border-width:initial;border-style:none;border-color:initial;border-image:initial;padding:16px;font:inherit}button.show-more:focus{outline:0;text-decoration:underline}mwc-list>*{margin:8px 0px}ha-list-item{height:40px;--mdc-ripple-color:transparent}`}]}}),n.oi);t()}catch(e){t(e)}}))},25347:function(e,t,i){var a=i(44249),n=(i(9359),i(56475),i(70104),i(57243)),s=i(15093),o=i(76002),r=(i(54977),i(46329)),l=i(28008);(0,a.Z)([(0,s.Mo)("ha-device-info-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"device",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"method",key:"render",value:function(){return n.dy`
      <ha-card outlined .header=${this.hass.localize("ui.panel.config.devices.device_info",{type:this.hass.localize(`ui.panel.config.devices.type.${this.device.entry_type||"device"}_heading`)})}>
        <div class="card-content">
          ${this.device.model?n.dy`<div class="model">
                ${this.device.model}
                ${this.device.model_id?n.dy`(${this.device.model_id})`:""}
              </div>`:this.device.model_id?n.dy`<div class="model">${this.device.model_id}</div>`:""}
          ${this.device.manufacturer?n.dy`
                <div class="manuf">
                  ${this.hass.localize("ui.panel.config.integrations.config_entry.manuf",{manufacturer:this.device.manufacturer})}
                </div>
              `:""}
          ${this.device.via_device_id?n.dy`
                <div class="extra-info">
                  ${this.hass.localize("ui.panel.config.integrations.config_entry.via")}
                  <span class="hub"><a href="/config/devices/device/${this.device.via_device_id}">${this._computeDeviceName(this.device.via_device_id)}</a></span>
                </div>
              `:""}
          ${this.device.sw_version?n.dy`
                <div class="extra-info">
                  ${this.hass.localize("ui.panel.config.integrations.config_entry."+("service"!==this.device.entry_type||this.device.hw_version?"firmware":"version"),{version:this.device.sw_version})}
                </div>
              `:""}
          ${this.device.hw_version?n.dy`
                <div class="extra-info">
                  ${this.hass.localize("ui.panel.config.integrations.config_entry.hardware",{version:this.device.hw_version})}
                </div>
              `:""}
          ${this.device.serial_number?n.dy`
                <div class="extra-info">
                  ${this.hass.localize("ui.panel.config.integrations.config_entry.serial_number",{serial_number:this.device.serial_number})}
                </div>
              `:""}
          ${this._getAddresses().map((([e,t])=>n.dy`
              <div class="extra-info">
                ${"mac"===e?"MAC":(0,o.Q)(e)}:
                ${t.toUpperCase()}
              </div>
            `))}
          <slot></slot>
        </div>
        <slot name="actions"></slot>
      </ha-card>
    `}},{kind:"method",key:"_getAddresses",value:function(){return this.device.connections.filter((e=>"mac"===e[0]||"bluetooth"===e[0]))}},{kind:"method",key:"_computeDeviceName",value:function(e){const t=this.hass.devices[e];return t?(0,r.jL)(t,this.hass):`<${this.hass.localize("ui.panel.config.integrations.config_entry.unknown_via_device")}>`}},{kind:"get",static:!0,key:"styles",value:function(){return[l.Qx,n.iv`:host{display:block}ha-card{flex:1 0 100%;min-width:0}.device{width:30%}.extra-info{margin-top:8px;word-wrap:break-word}.manuf,.model{color:var(--secondary-text-color);word-wrap:break-word}`]}}]}}),n.oi)},65811:function(e,t,i){var a=i(44249),n=(i(9359),i(56475),i(70104),i(87319),i(57243)),s=i(15093),o=i(27486),r=i(1416),l=(i(54977),i(13928),i(46329));(0,a.Z)([(0,s.Mo)("ha-device-via-devices-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"deviceId",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_showAll",value:()=>!1},{kind:"field",key:"_viaDevices",value(){return(0,o.Z)(((e,t)=>Object.values(t).filter((t=>t.via_device_id===e)).sort(((e,t)=>(0,r.fe)((0,l.jL)(e,this.hass),(0,l.jL)(t,this.hass),this.hass.locale.language)))))}},{kind:"method",key:"render",value:function(){const e=this._viaDevices(this.deviceId,this.hass.devices);return 0===e.length?n.Ld:n.dy`
      <ha-card>
        <h1 class="card-header">
          ${this.hass.localize("ui.panel.config.devices.connected_devices.heading")}
        </h1>
        ${(this._showAll?e:e.slice(0,10)).map((e=>n.dy`
            <a href=${`/config/devices/device/${e.id}`}>
              <mwc-list-item hasMeta>
                ${(0,l.jL)(e,this.hass)}
                <ha-icon-next slot="meta"></ha-icon-next>
              </mwc-list-item>
            </a>
          `))}
        ${!this._showAll&&e.length>10?n.dy`
              <button class="show-more" @click=${this._toggleShowAll}>
                ${this.hass.localize("ui.panel.config.devices.connected_devices.show_more",{count:e.length-10})}
              </button>
            `:""}
      </ha-card>
    `}},{kind:"method",key:"_toggleShowAll",value:function(){this._showAll=!this._showAll}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{display:block}.card-header{padding-bottom:0}a{text-decoration:none;color:var(--primary-text-color)}button.show-more{color:var(--primary-color);text-align:left;cursor:pointer;background:0 0;border-width:initial;border-style:none;border-color:initial;border-image:initial;padding:16px;font:inherit}button.show-more:focus{outline:0;text-decoration:underline}`}]}}),n.oi)},53928:function(e,t,i){i.d(t,{J:()=>s});var a=i(36522);const n=()=>i.e("20353").then(i.bind(i,25842)),s=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-device-automation",dialogImport:n,dialogParams:t})}},7199:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=i(72621),s=(i(92745),i(9359),i(56475),i(1331),i(31526),i(70104),i(52924),i(60738)),o=i(57243),r=i(15093),l=i(20552),d=i(27486),c=i(72344),h=i(73358),u=i(73850),f=i(59847),v=i(47194),m=i(1416),p=i(34798),g=i(47558),y=(i(44925),i(99426),i(34273),i(23334),i(13928),i(37583),i(41307),i(56032)),_=i(43546),b=i(75101),k=i(30635),w=i(46329),$=i(6823),x=i(63318),C=i(57816),z=i(93352),A=i(2357),E=i(76131),L=(i(34515),i(87979),i(28008)),S=i(88238),D=i(58014),M=i(16581),I=i(59360),P=(i(25347),i(65811),i(53928)),B=i(31993),H=i(21168),Z=i(41927),j=e([y,M,I]);[y,M,I]=j.then?(await j)():j;const N="M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",O="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",V="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",W="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",F="M12,2A3,3 0 0,1 15,5V11A3,3 0 0,1 12,14A3,3 0 0,1 9,11V5A3,3 0 0,1 12,2M19,11C19,14.53 16.39,17.44 13,17.93V21H11V17.93C7.61,17.44 5,14.53 5,11H7A5,5 0 0,0 12,16A5,5 0 0,0 17,11H19Z",T="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z",U="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z",R="M17,13H13V17H11V13H7V11H11V7H13V11H17M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z";(0,a.Z)([(0,r.Mo)("ha-config-device-page")],(function(e,t){class a extends t{constructor(...t){super(...t),e(this)}}return{F:a,d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"entries",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"manifests",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"deviceId",value:void 0},{kind:"field",decorators:[(0,r.Cb)({type:Boolean,reflect:!0})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,r.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"showAdvanced",value:()=>!1},{kind:"field",decorators:[(0,r.SB)()],key:"_related",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_diagnosticDownloadLinks",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_deleteButtons",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_deviceActions",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_deviceAlerts",value:void 0},{kind:"field",decorators:[(0,r.SB)(),(0,s.F_)({context:k.we,subscribe:!0})],key:"_entityReg",value:void 0},{kind:"field",key:"_logbookTime",value:()=>({recent:86400})},{kind:"field",key:"_integrations",value:()=>(0,d.Z)(((e,t,i)=>{const a={};for(const e of t)a[e.entry_id]=e;const n={};for(const e of i)n[e.domain]=e;const s=e.config_entries.filter((e=>e in a)).map((e=>a[e]));return(0,b.Pk)(s,e.primary_config_entry)}))},{kind:"field",key:"_entities",value(){return(0,d.Z)(((e,t)=>t.filter((t=>t.device_id===e)).map((e=>({...e,stateName:this._computeEntityName(e)}))).sort(((e,t)=>(0,m.$K)(e.stateName||`zzz${e.entity_id}`,t.stateName||`zzz${t.entity_id}`,this.hass.locale.language)))))}},{kind:"field",key:"_deviceIdInList",value:()=>(0,d.Z)((e=>[e]))},{kind:"field",key:"_entityIds",value:()=>(0,d.Z)((e=>e.map((e=>e.entity_id))))},{kind:"field",key:"_entitiesByCategory",value:()=>(0,d.Z)((e=>{const t=(0,g.v)(e,(e=>{const t=(0,u.M)(e.entity_id);return h.a5.includes(t)?"assist":"event"===t||"notify"===t?t:e.entity_category?e.entity_category:h.zF.includes(t)?"sensor":"control"}));for(const e of["assist","config","control","diagnostic","event","notify","sensor"])e in t||(t[e]=[]);return t}))},{kind:"field",key:"_batteryEntity",value(){return(0,d.Z)((e=>(0,x.eD)(this.hass,e)))}},{kind:"field",key:"_batteryChargingEntity",value(){return(0,d.Z)((e=>(0,x.wX)(this.hass,e)))}},{kind:"method",key:"willUpdate",value:function(e){(0,n.Z)(a,"willUpdate",this,3)([e]),(e.has("deviceId")||e.has("devices")||e.has("entries"))&&(this._diagnosticDownloadLinks=void 0,this._deleteButtons=void 0,this._deviceActions=void 0,this._deviceAlerts=void 0),this._diagnosticDownloadLinks&&this._deleteButtons&&this._deviceActions&&this._deviceAlerts||!this.deviceId||!this.entries||(this._diagnosticDownloadLinks=Math.random(),this._deleteButtons=[],this._deviceActions=[],this._deviceAlerts=[],this._getDiagnosticButtons(this._diagnosticDownloadLinks),this._getDeleteActions(),this._getDeviceActions(),this._getDeviceAlerts())}},{kind:"method",key:"firstUpdated",value:function(e){(0,n.Z)(a,"firstUpdated",this,3)([e]),(0,B.O)()}},{kind:"method",key:"updated",value:function(e){(0,n.Z)(a,"updated",this,3)([e]),e.has("deviceId")&&this._findRelated()}},{kind:"method",key:"render",value:function(){if(!this.hass||!this.deviceId)return o.Ld;const e=this.hass.devices[this.deviceId];if(!e)return o.dy`
        <hass-error-screen .hass=${this.hass} .error=${this.hass.localize("ui.panel.config.devices.device_not_found")}></hass-error-screen>
      `;const t=(0,w.jL)(e,this.hass),i=this._integrations(e,this.entries,this.manifests),a=this._entities(this.deviceId,this._entityReg),n=this._entitiesByCategory(a),s=this._batteryEntity(a),r=this._batteryChargingEntity(a),d=s?this.hass.states[s.entity_id]:void 0,h=d?(0,f.N)(d):void 0,u=r?this.hass.states[r.entity_id]:void 0,m=e.area_id?this.hass.areas[e.area_id]:void 0,p=i.map((e=>o.dy`<a slot="actions" href=${`/config/integrations/integration/${e.domain}#config_entry=${e.entry_id}`}>
          <ha-list-item graphic="icon" hasMeta>
            <img slot="graphic" alt=${(0,C.Lh)(this.hass.localize,e.domain)} src=${(0,S.X1)({domain:e.domain,type:"icon",darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer" @error=${this._onImageError} @load=${this._onImageLoad}/>

            ${(0,C.Lh)(this.hass.localize,e.domain)}
            <ha-icon-next slot="meta"></ha-icon-next>
          </ha-list-item>
        </a>`)),g=[...this._deviceActions||[]];Array.isArray(this._diagnosticDownloadLinks)&&g.push(...this._diagnosticDownloadLinks),this._deleteButtons&&g.push(...this._deleteButtons),g.sort(((e,t)=>"warning"===e.classes&&"warning"!==t.classes?1:"warning"!==e.classes&&"warning"===t.classes?-1:0));const y=g.shift();e.disabled_by&&p.push(o.dy`
        <ha-alert alert-type="warning">
          ${this.hass.localize("ui.panel.config.devices.enabled_cause",{type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`),cause:this.hass.localize(`ui.panel.config.devices.disabled_by.${e.disabled_by}`)})}
        </ha-alert>
        ${"user"===e.disabled_by?o.dy`
              <div class="card-actions" slot="actions">
                <mwc-button unelevated @click=${this._enableDevice}>
                  ${this.hass.localize("ui.common.enable")}
                </mwc-button>
              </div>
            `:""}
      `),this._renderIntegrationInfo(e,i,p);const _=e.disabled_by?this.hass.localize("ui.panel.config.devices.add_prompt_disabled"):this.hass.localize("ui.panel.config.devices.add_prompt_enabled"),b=(0,c.p)(this.hass,"automation")?o.dy`
          <ha-card outlined>
            <h1 class="card-header">
              ${this.hass.localize("ui.panel.config.devices.automation.automations_heading")}
              <ha-icon-button @click=${this._showAutomationDialog} .disabled=${e.disabled_by} .label=${e.disabled_by?this.hass.localize("ui.panel.config.devices.automation.create_disable",{type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)}):this.hass.localize("ui.panel.config.devices.automation.create",{type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)})} .path=${R}></ha-icon-button>
            </h1>
            ${this._related?.automation?.length?o.dy`
                  <div class="items">
                    ${this._related.automation.map((e=>{const t=this.hass.states[e];return t?o.dy`<ha-tooltip placement="left" .disabled=${!!t.attributes.id} .content=${this.hass.localize("ui.panel.config.devices.cant_edit")}>
                            <a href=${(0,l.o)(t.attributes.id?`/config/automation/edit/${encodeURIComponent(t.attributes.id)}`:void 0)}>
                              <ha-list-item hasMeta .automation=${t} .disabled=${!t.attributes.id}>
                                ${(0,v.C)(t)}
                                <ha-icon-next slot="meta"></ha-icon-next>
                              </ha-list-item>
                            </a>
                          </ha-tooltip>`:o.Ld}))}
                  </div>
                `:o.dy`
                  <div class="card-content">
                    ${this.hass.localize("ui.panel.config.devices.add_prompt",{name:this.hass.localize("ui.panel.config.devices.automation.automations"),type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)})}
                    ${_}
                  </div>
                `}
          </ha-card>
        `:"",k=(0,c.p)(this.hass,"scene")&&a.length?o.dy`
            <ha-card outlined>
              <h1 class="card-header">
                ${this.hass.localize("ui.panel.config.devices.scene.scenes_heading")}

                <ha-icon-button @click=${this._createScene} .disabled=${e.disabled_by} .label=${e.disabled_by?this.hass.localize("ui.panel.config.devices.scene.create_disable",{type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)}):this.hass.localize("ui.panel.config.devices.scene.create",{type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)})} .path=${R}></ha-icon-button>
              </h1>
              ${this._related?.scene?.length?o.dy`
                    <div class="items">
                      ${this._related.scene.map((e=>{const t=this.hass.states[e];return t?o.dy`
                              <ha-tooltip placement="left" .disabled=${!!t.attributes.id} .content=${this.hass.localize("ui.panel.config.devices.cant_edit")}>
                                <a href=${(0,l.o)(t.attributes.id?`/config/scene/edit/${t.attributes.id}`:void 0)}>
                                  <ha-list-item hasMeta .scene=${t} .disabled=${!t.attributes.id}>
                                    ${(0,v.C)(t)}
                                    <ha-icon-next slot="meta"></ha-icon-next>
                                  </ha-list-item>
                                </a>
                              </ha-tooltip>
                            `:o.Ld}))}
                    </div>
                  `:o.dy`
                    <div class="card-content">
                      ${this.hass.localize("ui.panel.config.devices.add_prompt",{name:this.hass.localize("ui.panel.config.devices.scene.scenes"),type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)})}
                      ${_}
                    </div>
                  `}
            </ha-card>
          `:"",$=(0,c.p)(this.hass,"script")?o.dy`
          <ha-card outlined>
            <h1 class="card-header">
              ${this.hass.localize("ui.panel.config.devices.script.scripts_heading")}
              <ha-icon-button @click=${this._showScriptDialog} .disabled=${e.disabled_by} .label=${e.disabled_by?this.hass.localize("ui.panel.config.devices.script.create_disable",{type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)}):this.hass.localize("ui.panel.config.devices.script.create",{type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)})} .path=${R}></ha-icon-button>
            </h1>
            ${this._related?.script?.length?o.dy`
                  <div class="items">
                    ${this._related.script.map((e=>{const t=this.hass.states[e],i=this._entityReg.find((t=>t.entity_id===e));let a=`/config/script/show/${t.entity_id}`;return i&&(a=`/config/script/edit/${i.unique_id}`),t?o.dy`
                            <a href=${a}>
                              <ha-list-item hasMeta .script=${e}>
                                ${(0,v.C)(t)}
                                <ha-icon-next slot="meta"></ha-icon-next>
                              </ha-list-item>
                            </a>
                          `:""}))}
                  </div>
                `:o.dy`
                  <div class="card-content">
                    ${this.hass.localize("ui.panel.config.devices.add_prompt",{name:this.hass.localize("ui.panel.config.devices.script.scripts"),type:this.hass.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)})}
                    ${_}
                  </div>
                `}
          </ha-card>
        `:"";return o.dy` <hass-subpage .hass=${this.hass} .narrow=${this.narrow} .header=${t}>
      <ha-icon-button slot="toolbar-icon" .path=${U} @click=${this._showSettings} .label=${this.hass.localize("ui.panel.config.devices.edit_settings")}></ha-icon-button>
      <div class="container">
        <div class="header fullwidth">
          ${m?o.dy`<div class="header-name">
                <a href="/config/areas/area/${m.area_id}">${this.hass.localize("ui.panel.config.integrations.config_entry.area",{area:m.name||"Unnamed Area"})}</a>
              </div>`:""}
          <div class="header-right">
            ${!d||"binary_sensor"!==h&&isNaN(d.state)?"":o.dy`
                  <div class="battery">
                    ${"sensor"===h?this.hass.formatEntityState(d):o.Ld}
                    <ha-battery-icon .hass=${this.hass} .batteryStateObj=${d} .batteryChargingStateObj=${u}></ha-battery-icon>
                  </div>
                `}
            ${i.length?o.dy`
                  <img alt=${(0,C.Lh)(this.hass.localize,i[0].domain)} src=${(0,S.X1)({domain:i[0].domain,type:"logo",darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer" @load=${this._onImageLoad} @error=${this._onImageError}/>
                `:""}
          </div>
        </div>
        <div class="column">
          ${this._deviceAlerts?.length?o.dy`
                <div>
                  ${this._deviceAlerts.map((e=>o.dy`
                      <ha-alert .alertType=${e.level}>
                        ${e.text}
                      </ha-alert>
                    `))}
                </div>
              `:""}
          <ha-device-info-card .hass=${this.hass} .device=${e}>
            ${p}
            ${y||g.length?o.dy`
                  <div class="card-actions" slot="actions">
                    <div>
                      <a href=${(0,l.o)(y.href)} rel=${(0,l.o)(y.target?"noreferrer":void 0)} target=${(0,l.o)(y.target)}>
                        <mwc-button class=${(0,l.o)(y.classes)} .action=${y.action} @click=${this._deviceActionClicked} graphic="icon">
                          ${y.label}
                          ${y.icon?o.dy`
                                <ha-svg-icon class=${(0,l.o)(y.classes)} .path=${y.icon} slot="graphic"></ha-svg-icon>
                              `:""}
                          ${y.trailingIcon?o.dy`
                                <ha-svg-icon .path=${y.trailingIcon} slot="trailingIcon"></ha-svg-icon>
                              `:""}
                        </mwc-button>
                      </a>
                    </div>

                    ${g.length?o.dy`
                          <ha-button-menu>
                            <ha-icon-button slot="trigger" .label=${this.hass.localize("ui.common.menu")} .path=${V}></ha-icon-button>
                            ${g.map((e=>{const t=o.dy`<mwc-list-item class=${(0,l.o)(e.classes)} .action=${e.action} @click=${this._deviceActionClicked} graphic="icon" .hasMeta=${Boolean(e.trailingIcon)}>
                                ${e.label}
                                ${e.icon?o.dy`
                                      <ha-svg-icon class=${(0,l.o)(e.classes)} .path=${e.icon} slot="graphic"></ha-svg-icon>
                                    `:""}
                                ${e.trailingIcon?o.dy`
                                      <ha-svg-icon slot="meta" .path=${e.trailingIcon}></ha-svg-icon>
                                    `:""}
                              </mwc-list-item>`;return e.href?o.dy`<a href=${e.href} target=${(0,l.o)(e.target)} rel=${(0,l.o)(e.target?"noreferrer":void 0)}>${t}
                                  </a>`:t}))}
                          </ha-button-menu>
                        `:""}
                  </div>
                `:""}
          </ha-device-info-card>
          ${this.narrow?"":[b,k,$]}
        </div>
        <div class="column">
          ${["control","sensor","notify","event","assist","config","diagnostic"].map((i=>n[i].length>0||0===a.length&&"control"===i?o.dy`
                  <ha-device-entities-card .hass=${this.hass} .header=${this.hass.localize(`ui.panel.config.devices.entities.${i}`)} .deviceName=${t} .entities=${n[i]} .showHidden=${null!==e.disabled_by}>
                  </ha-device-entities-card>
                `:""))}
          <ha-device-via-devices-card .hass=${this.hass} .deviceId=${this.deviceId}></ha-device-via-devices-card>
        </div>
        <div class="column">
          ${this.narrow?[b,k,$]:""}
          ${(0,c.p)(this.hass,"logbook")?o.dy`
                <ha-card outlined>
                  <h1 class="card-header">
                    ${this.hass.localize("panel.logbook")}
                  </h1>
                  <ha-logbook .hass=${this.hass} .time=${this._logbookTime} .entityIds=${this._entityIds(a)} .deviceIds=${this._deviceIdInList(this.deviceId)} virtualize narrow no-icon></ha-logbook>
                </ha-card>
              `:""}
        </div>
      </div>
    </hass-subpage>`}},{kind:"method",key:"_getDiagnosticButtons",value:async function(e){if(!(0,c.p)(this.hass,"diagnostics"))return;const t=this.hass.devices[this.deviceId];if(!t)return;let i=await Promise.all(this._integrations(t,this.entries,this.manifests).map((async e=>{if("loaded"!==e.state)return!1;let t;try{t=await(0,$.lf)(this.hass,e.domain)}catch(e){if("not_found"===e.code)return!1;throw e}return!(!t.handlers.device&&!t.handlers.config_entry)&&{link:t.handlers.device?(0,$.ZK)(e.entry_id,this.deviceId):(0,$.iP)(e.entry_id),domain:e.domain}})));i=i.filter(Boolean),this._diagnosticDownloadLinks===e&&i.length>0&&(this._diagnosticDownloadLinks=i.map((e=>({href:e.link,icon:W,action:e=>this._signUrl(e),label:i.length>1?this.hass.localize("ui.panel.config.devices.download_diagnostics_integration",{integration:(0,C.Lh)(this.hass.localize,e.domain)}):this.hass.localize("ui.panel.config.devices.download_diagnostics")}))))}},{kind:"method",key:"_getDeleteActions",value:function(){const e=this.hass.devices[this.deviceId];if(!e)return;const t=[];this._integrations(e,this.entries,this.manifests).forEach((i=>{"loaded"===i.state&&i.supports_remove_device&&t.push({action:async()=>{if(await(0,E.showConfirmationDialog)(this,{text:this._integrations(e,this.entries,this.manifests).length>1?this.hass.localize("ui.panel.config.devices.confirm_delete_integration",{integration:(0,C.Lh)(this.hass.localize,i.domain)}):this.hass.localize("ui.panel.config.devices.confirm_delete"),confirmText:this.hass.localize("ui.common.delete"),dismissText:this.hass.localize("ui.common.cancel"),destructive:!0}))try{await(0,w.dl)(this.hass,this.deviceId,i.entry_id)}catch(e){(0,E.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.devices.error_delete"),text:e.message})}},classes:"warning",icon:O,label:this._integrations(e,this.entries,this.manifests).length>1?this.hass.localize("ui.panel.config.devices.delete_device_integration",{integration:(0,C.Lh)(this.hass.localize,i.domain)}):this.hass.localize("ui.panel.config.devices.delete_device")})})),t.length>0&&(this._deleteButtons=t)}},{kind:"method",key:"_getDeviceActions",value:async function(){const e=this.hass.devices[this.deviceId];if(!e)return;const t=[],a=e.configuration_url?.startsWith("homeassistant://")||!1,n=a?e.configuration_url.replace("homeassistant://","/"):e.configuration_url;n&&t.push({href:n,target:a?void 0:"_blank",icon:N,label:this.hass.localize("ui.panel.config.devices.open_configuration_url"),trailingIcon:T});const s=this._entities(this.deviceId,this._entityReg).find((e=>"assist_satellite"===(0,u.M)(e.entity_id))),o=this._integrations(e,this.entries,this.manifests).map((e=>e.domain));if(!o.includes("voip")&&s&&(0,Z.Bg)(this.hass.states[s.entity_id])&&t.push({action:this._voiceAssistantSetup,label:this.hass.localize("ui.panel.config.devices.set_up_voice_assistant"),icon:F}),o.includes("mqtt")){const a=(await i.e("90863").then(i.bind(i,87516))).getMQTTDeviceActions(this,e);t.push(...a)}if(o.includes("zha")){const a=await i.e("80927").then(i.bind(i,45004)),n=await a.getZHADeviceActions(this,this.hass,e);t.push(...n)}if(o.includes("zwave_js")){const a=await i.e("99706").then(i.bind(i,40170)),n=await a.getZwaveDeviceActions(this,this.hass,e);t.push(...n)}if(o.includes("matter")){const a=await i.e("70437").then(i.bind(i,67991)),n=a.getMatterDeviceDefaultActions(this,this.hass,e);t.push(...n),a.getMatterDeviceActions(this,this.hass,e).then((e=>{this._deviceActions=[...e,...this._deviceActions||[]]}))}this._deviceActions=t}},{kind:"method",key:"_getDeviceAlerts",value:async function(){const e=this.hass.devices[this.deviceId];if(!e)return;const t=[];if(this._integrations(e,this.entries,this.manifests).map((e=>e.domain)).includes("zwave_js")){const a=await i.e("53131").then(i.bind(i,26665)),n=await a.getZwaveDeviceAlerts(this.hass,e);t.push(...n)}t.length&&(this._deviceAlerts=t)}},{kind:"method",key:"_computeEntityName",value:function(e){if(e.name)return e.name;const t=this.hass.states[e.entity_id];return t?(0,v.C)(t):null}},{kind:"method",key:"_onImageLoad",value:function(e){e.target.style.display="inline-block"}},{kind:"method",key:"_onImageError",value:function(e){e.target.style.display="none"}},{kind:"method",key:"_findRelated",value:async function(){this._related=await(0,A.K)(this.hass,"device",this.deviceId)}},{kind:"method",key:"_createScene",value:function(){const e={};this._entities(this.deviceId,this._entityReg).forEach((t=>{e[t.entity_id]=""})),(0,z.mR)({entities:e})}},{kind:"method",key:"_showScriptDialog",value:function(){(0,P.J)(this,{device:this.hass.devices[this.deviceId],entityReg:this._entityReg,script:!0})}},{kind:"method",key:"_showAutomationDialog",value:function(){(0,P.J)(this,{device:this.hass.devices[this.deviceId],entityReg:this._entityReg,script:!1})}},{kind:"method",key:"_renderIntegrationInfo",value:function(e,t,a){const n=t.map((e=>e.domain));n.includes("zha")&&(i.e("72259").then(i.bind(i,39724)),a.push(o.dy`
        <ha-device-info-zha .hass=${this.hass} .device=${e}></ha-device-info-zha>
      `)),n.includes("zwave_js")&&(i.e("4253").then(i.bind(i,66705)),a.push(o.dy`
        <ha-device-info-zwave_js .hass=${this.hass} .device=${e}></ha-device-info-zwave_js>
      `)),n.includes("matter")&&(i.e("35949").then(i.bind(i,17547)),a.push(o.dy`
        <ha-device-info-matter .hass=${this.hass} .device=${e}></ha-device-info-matter>
      `))}},{kind:"method",key:"_showSettings",value:async function(){const e=this.hass.devices[this.deviceId];(0,B.r)(this,{device:e,updateEntry:async t=>{const i=e.name_by_user||e.name,a=t.name_by_user;if("user"===t.disabled_by&&"user"!==e.disabled_by){for(const i of e.config_entries)if(!Object.values(this.hass.devices).some((t=>t.id!==e.id&&t.config_entries.includes(i)))){const e=this.entries.find((e=>e.entry_id===i));if(e&&!e.disabled_by&&await(0,E.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.devices.confirm_disable_config_entry",{entry_name:e.title}),confirmText:this.hass.localize("ui.common.yes"),dismissText:this.hass.localize("ui.common.no")})){let e;try{e=await(0,b.Ny)(this.hass,i)}catch(e){return void(0,E.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.integrations.config_entry.disable_error"),text:e.message})}e.require_restart&&(0,E.showAlertDialog)(this,{text:this.hass.localize("ui.panel.config.integrations.config_entry.disable_restart_confirm")}),delete t.disabled_by}}}else null!==t.disabled_by&&"user"!==t.disabled_by&&delete t.disabled_by;try{await(0,w.t1)(this.hass,this.deviceId,t)}catch(e){return void(0,E.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.devices.update_device_error"),text:e.message})}if(!i||!a||i===a)return;const n=this._entities(this.deviceId,this._entityReg);let s=!1,r=[];if(this.showAdvanced){const e=(0,p.l)(i),t=(0,p.l)(a);r=n.map((i=>{const a=i.entity_id;if(a.includes(e)){const i=a.replace(e,t);return{oldId:a,newId:i}}return{oldId:a}}));const l=r.filter((e=>e.newId)).map((e=>o.dy`<tr>
                  <td>${e.oldId}</td>
                  <td>${e.newId}</td>
                </tr>`)),d=r.filter((e=>!e.newId)).map((e=>o.dy`<li>${e.oldId}</li>`));l.length?s=await(0,E.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.devices.confirm_rename_entity_ids"),text:o.dy`${this.hass.localize("ui.panel.config.devices.confirm_rename_entity_ids_warning")} <br/><br/>
                <ha-expansion-panel outlined>
                  <span slot="header">${this.hass.localize("ui.panel.config.devices.confirm_rename_entity_will_rename",{count:l.length})}</span>
                  <div style="overflow:auto">
                    <table style="width:100%;text-align:var(--float-start)">
                      <tr>
                        <th>
                          ${this.hass.localize("ui.panel.config.devices.confirm_rename_old")}
                        </th>
                        <th>
                          ${this.hass.localize("ui.panel.config.devices.confirm_rename_new")}
                        </th>
                      </tr>
                      ${l}
                    </table>
                  </div>
                </ha-expansion-panel>
                ${d.length?o.dy`<ha-expansion-panel outlined>
                      <span slot="header">${this.hass.localize("ui.panel.config.devices.confirm_rename_entity_wont_rename",{count:d.length,deviceSlug:e})}</span>
                      ${d}</ha-expansion-panel>`:o.Ld} `,confirmText:this.hass.localize("ui.common.rename"),dismissText:this.hass.localize("ui.common.no"),warning:!0}):d.length&&await(0,E.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.devices.confirm_rename_entity_no_renamable_entity_ids"),text:o.dy`<ha-expansion-panel outlined>
                <span slot="header">${this.hass.localize("ui.panel.config.devices.confirm_rename_entity_wont_rename",{deviceSlug:e,count:d.length})}</span>
                ${d}
              </ha-expansion-panel>`})}const l=n.map((e=>{const t=e.name||e.stateName;let n,o,l,d=!1;if(e.has_entity_name&&!e.name?l=!1:!e.has_entity_name||e.name!==i&&e.name!==a?t&&t.includes(i)?(l=!0,o=t.replace(i,a)):l=!1:(l=!0,o=null),s){const t=r?.find((t=>t.oldId===e.entity_id));t?.newId&&(d=!0,n=t.newId)}if(void 0!==o||void 0!==n)return(0,x.Nv)(this.hass,e.entity_id,{name:l?o:void 0,new_entity_id:d?n:void 0})}));await Promise.all(l)}})}},{kind:"method",key:"_enableDevice",value:async function(){await(0,w.t1)(this.hass,this.deviceId,{disabled_by:null})}},{kind:"method",key:"_signUrl",value:async function(e){const t=e.currentTarget.closest("a"),i=await(0,_.iI)(this.hass,t.getAttribute("href"));(0,D.N)(i.path)}},{kind:"method",key:"_deviceActionClicked",value:function(e){e.currentTarget.action&&(e.preventDefault(),e.currentTarget.action(e))}},{kind:"field",key:"_voiceAssistantSetup",value(){return()=>{(0,H.k)(this,{deviceId:this.deviceId})}}},{kind:"get",static:!0,key:"styles",value:function(){return[L.Qx,o.iv`.battery,.header-right{align-self:center;display:flex}.container{display:flex;flex-wrap:wrap;margin:32px auto;max-width:1000px}.card-header{display:flex;align-items:center;justify-content:space-between;padding-bottom:12px}.card-header ha-icon-button{margin-right:-8px;margin-inline-end:-8px;margin-inline-start:initial;color:var(--primary-color);height:auto;direction:var(--direction)}.device-info{padding:16px}h1{margin:0;font-family:var(--paper-font-headline_-_font-family);-webkit-font-smoothing:var(--paper-font-headline_-_-webkit-font-smoothing);font-size:var(--paper-font-headline_-_font-size);font-weight:var(--paper-font-headline_-_font-weight);letter-spacing:var(--paper-font-headline_-_letter-spacing);line-height:var(--paper-font-headline_-_line-height);opacity:var(--dark-primary-opacity)}.header{display:flex;justify-content:space-between}.header-name{display:flex;align-items:center;padding-left:8px;padding-inline-start:8px;direction:var(--direction)}.column,.fullwidth{padding:8px;box-sizing:border-box}.column{width:33%;flex-grow:1}.fullwidth{width:100%;flex-grow:1}.header-right img{height:30px}.header-right:first-child{width:100%;justify-content:flex-end}.header-right>:not(:first-child){margin-left:16px;margin-inline-start:16px;margin-inline-end:initial;direction:var(--direction)}.battery{align-items:center;white-space:nowrap}.column>:not(:first-child){margin-top:16px}:host([narrow]) .column{width:100%}:host([narrow]) .container{margin-top:0}a{text-decoration:none;color:var(--primary-color)}ha-card a{color:var(--primary-text-color)}ha-svg-icon[slot=trailingIcon]{display:block;width:18px;height:18px;margin-inline-start:8px;margin-inline-end:initial}ha-svg-icon[slot=meta]{width:18px;height:18px}.items{padding-bottom:16px}ha-card:has(ha-logbook){padding-bottom:var(--ha-card-border-radius,12px)}ha-logbook{height:400px}:host([narrow]) ha-logbook{height:235px}.card-actions{display:flex;justify-content:space-between;align-items:center}`]}}]}}),o.oi);t()}catch(e){t(e)}}))},77148:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=i(72621),s=(i(92745),i(9359),i(68107),i(56475),i(1331),i(31526),i(70104),i(52924),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814),i(75656),i(50100),i(18084),i(60738)),o=i(57243),r=i(18672),l=i(15093),d=i(27486),c=i(75011),h=i(64214),u=i(68958),f=i(59847),v=i(46355),m=i(83523),p=i(35076),g=(i(10504),i(44925),i(99426),i(34273),i(48103),i(51868),i(20130),i(76268),i(43082),i(87315)),y=(i(86735),i(9425),i(23334),i(7843),i(4573),i(82100)),_=i(75101),b=i(30635),k=i(12068),w=i(46329),$=i(63318),x=i(63860),C=i(76131),z=(i(38419),i(6736)),A=i(28008),E=i(88238),L=i(61107),S=i(82967),D=(i(44536),i(84361)),M=i(26345),I=e([g,h]);[g,h]=I.then?(await I)():I;const P="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z",B="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",H="M7,10L12,15L17,10H7Z",Z="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",j="M20 2H4C2.9 2 2 2.9 2 4V20C2 21.11 2.9 22 4 22H20C21.11 22 22 21.11 22 20V4C22 2.9 21.11 2 20 2M4 6L6 4H10.9L4 10.9V6M4 13.7L13.7 4H18.6L4 18.6V13.7M20 18L18 20H13.1L20 13.1V18M20 10.3L10.3 20H5.4L20 5.4V10.3Z",N="M12 2C17.5 2 22 6.5 22 12S17.5 22 12 22 2 17.5 2 12 6.5 2 12 2M12 4C10.1 4 8.4 4.6 7.1 5.7L18.3 16.9C19.3 15.5 20 13.8 20 12C20 7.6 16.4 4 12 4M16.9 18.3L5.7 7.1C4.6 8.4 4 10.1 4 12C4 16.4 7.6 20 12 20C13.9 20 15.6 19.4 16.9 18.3Z";(0,a.Z)([(0,l.Mo)("ha-config-devices-dashboard")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,l.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,l.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,l.Cb)({attribute:!1})],key:"entries",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_subEntries",value:void 0},{kind:"field",decorators:[(0,l.SB)(),(0,s.F_)({context:b.we,subscribe:!0})],key:"entities",value:void 0},{kind:"field",decorators:[(0,l.Cb)({attribute:!1})],key:"manifests",value:void 0},{kind:"field",decorators:[(0,l.Cb)({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_searchParms",value:()=>new URLSearchParams(window.location.search)},{kind:"field",decorators:[(0,l.SB)()],key:"_selected",value:()=>[]},{kind:"field",decorators:[(0,u.t)({storage:"sessionStorage",key:"devices-table-search",state:!0,subscribe:!1})],key:"_filter",value:()=>history.state?.filter||""},{kind:"field",decorators:[(0,u.t)({storage:"sessionStorage",key:"devices-table-filters-full",state:!0,subscribe:!1,serializer:k.B,deserializer:k.l})],key:"_filters",value:()=>({})},{kind:"field",decorators:[(0,l.SB)()],key:"_expandedFilter",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_labels",value:void 0},{kind:"field",decorators:[(0,u.t)({key:"devices-table-sort",state:!1,subscribe:!1})],key:"_activeSorting",value:void 0},{kind:"field",decorators:[(0,u.t)({key:"devices-table-grouping",state:!1,subscribe:!1})],key:"_activeGrouping",value:void 0},{kind:"field",decorators:[(0,u.t)({key:"devices-table-collapsed",state:!1,subscribe:!1})],key:"_activeCollapsed",value:void 0},{kind:"field",decorators:[(0,u.t)({key:"devices-table-column-order",state:!1,subscribe:!1})],key:"_activeColumnOrder",value:void 0},{kind:"field",decorators:[(0,u.t)({key:"devices-table-hidden-columns",state:!1,subscribe:!1})],key:"_activeHiddenColumns",value:void 0},{kind:"field",key:"_sizeController",value(){return new r.Z(this,{callback:e=>e[0]?.contentRect.width})}},{kind:"field",key:"_ignoreLocationChange",value:()=>!1},{kind:"method",key:"connectedCallback",value:function(){(0,n.Z)(i,"connectedCallback",this,3)([]),window.addEventListener("location-changed",this._locationChanged),window.addEventListener("popstate",this._popState)}},{kind:"method",key:"disconnectedCallback",value:function(){(0,n.Z)(i,"disconnectedCallback",this,3)([]),window.removeEventListener("location-changed",this._locationChanged),window.removeEventListener("popstate",this._popState)}},{kind:"field",key:"_locationChanged",value(){return()=>{this._ignoreLocationChange?this._ignoreLocationChange=!1:window.location.search.substring(1)!==this._searchParms.toString()&&(this._searchParms=new URLSearchParams(window.location.search),this._setFiltersFromUrl())}}},{kind:"field",key:"_popState",value(){return()=>{window.location.search.substring(1)!==this._searchParms.toString()&&(this._searchParms=new URLSearchParams(window.location.search),this._setFiltersFromUrl())}}},{kind:"field",key:"_states",value:()=>(0,d.Z)((e=>[{value:"disabled",label:e("ui.panel.config.devices.data_table.disabled_by")}]))},{kind:"method",key:"willUpdate",value:function(e){(0,n.Z)(i,"willUpdate",this,3)([e]),this.hasUpdated||this._setFiltersFromUrl()}},{kind:"method",key:"_setFiltersFromUrl",value:function(){const e=this._searchParms.get("domain"),t=this._searchParms.get("config_entry"),i=this._searchParms.get("sub_entry"),a=this._searchParms.has("label");(e||t||a)&&(this._filter=history.state?.filter||"",this._filters={"ha-filter-states":{value:[...this._filters["ha-filter-states"]?.value||[],"disabled"],items:void 0},"ha-filter-integrations":{value:e?[e]:[],items:void 0},config_entry:{value:t?[t]:[],items:void 0},sub_entry:{value:i?[i]:[],items:void 0}},this._filterLabel())}},{kind:"method",key:"_filterLabel",value:function(){const e=this._searchParms.get("label");e&&(this._filters={...this._filters,"ha-filter-labels":{value:[e],items:void 0}})}},{kind:"method",key:"_clearFilter",value:function(){this._filters={}}},{kind:"field",key:"_devicesAndFilterDomains",value(){return(0,d.Z)(((e,t,i,a,n,s,o,r)=>{let l=Object.values(e).map((e=>({...e,label_entries:[]})));const d={};for(const e of i)e.device_id&&(e.device_id in d||(d[e.device_id]=[]),d[e.device_id].push(e));const c={};for(const e of t)c[e.entry_id]=e;const h={};for(const e of n)h[e.domain]=e;let u;const f=new Set;Object.entries(s).forEach((([e,i])=>{if("config_entry"===e&&Array.isArray(i.value)&&i.value.length){l=l.filter((e=>e.config_entries.some((e=>i.value.includes(e)))));const e=t.filter((e=>e.entry_id&&i.value.includes(e.entry_id)));e.forEach((e=>{f.add(e.domain)})),1===e.length&&(u=e[0])}else if("sub_entry"===e&&Array.isArray(i.value)&&i.value.length){if(!Array.isArray(this._filters.config_entry?.value)||1!==this._filters.config_entry.value.length)return;const e=this._filters.config_entry.value[0];l=l.filter((t=>t.config_entries_subentries[e]&&i.value.some((i=>t.config_entries_subentries[e].includes(i))))),this._subEntries||this._loadSubEntries(e)}else if("ha-filter-integrations"===e&&Array.isArray(i.value)&&i.value.length){const e=t.filter((e=>i.value.includes(e.domain))).map((e=>e.entry_id));l=l.filter((t=>t.config_entries.some((t=>e.includes(t))))),i.value.forEach((e=>f.add(e)))}else"ha-filter-labels"===e&&Array.isArray(i.value)&&i.value.length?l=l.filter((e=>e.labels.some((e=>i.value.includes(e))))):i.items&&(l=l.filter((e=>i.items.has(e.id))))}));const v=s["ha-filter-states"]?.value;v?.length&&v.includes("disabled")||(l=l.filter((e=>!e.disabled_by)));return{devicesOutput:l.map((e=>{const t=(0,_.Pk)(e.config_entries.filter((e=>e in c)).map((e=>c[e])),e.primary_config_entry),i=(r&&e?.labels||[]).map((e=>r.find((t=>t.label_id===e))));return{...e,name:(0,w.jL)(e,this.hass,d[e.id]),model:e.model||`<${o("ui.panel.config.devices.data_table.unknown")}>`,manufacturer:e.manufacturer||`<${o("ui.panel.config.devices.data_table.unknown")}>`,area:e.area_id&&a[e.area_id]?a[e.area_id].name:"—",integration:t.length?t.map((e=>o(`component.${e.domain}.title`)||e.domain)).join(", "):this.hass.localize("ui.panel.config.devices.data_table.no_integration"),domains:t.map((e=>e.domain)),battery_entity:[this._batteryEntity(e.id,d),this._batteryChargingEntity(e.id,d)],battery_level:this.hass.states[this._batteryEntity(e.id,d)||""]?.state,label_entries:i}})),filteredConfigEntry:u,filteredDomains:f}}))}},{kind:"field",key:"_columns",value(){return(0,d.Z)((e=>({icon:{title:"",label:e("ui.panel.config.devices.data_table.icon"),type:"icon",moveable:!1,showNarrow:!0,template:e=>e.domains.length?o.dy`<img alt="" crossorigin="anonymous" referrerpolicy="no-referrer" src=${(0,E.X1)({domain:e.domains[0],type:"icon",darkOptimized:this.hass.themes?.darkMode})}/>`:""},name:{title:e("ui.panel.config.devices.data_table.device"),main:!0,sortable:!0,filterable:!0,direction:"asc",grows:!0,flex:2,minWidth:"150px",extraTemplate:e=>o.dy`
          ${e.label_entries.length?o.dy`
                <ha-data-table-labels .labels=${e.label_entries}></ha-data-table-labels>
              `:o.Ld}
        `},manufacturer:{title:e("ui.panel.config.devices.data_table.manufacturer"),sortable:!0,filterable:!0,groupable:!0,minWidth:"120px"},model:{title:e("ui.panel.config.devices.data_table.model"),sortable:!0,filterable:!0,minWidth:"120px"},area:{title:e("ui.panel.config.devices.data_table.area"),sortable:!0,filterable:!0,groupable:!0,minWidth:"120px"},integration:{title:e("ui.panel.config.devices.data_table.integration"),sortable:!0,filterable:!0,groupable:!0,minWidth:"120px"},battery_entity:{title:e("ui.panel.config.devices.data_table.battery"),showNarrow:!0,sortable:!0,filterable:!0,type:"numeric",maxWidth:"101px",minWidth:"101px",valueColumn:"battery_level",template:e=>{const t=e.battery_entity,i=t&&t[0]?this.hass.states[t[0]]:void 0,a=i?(0,f.N)(i):void 0,n=t&&t[1]?this.hass.states[t[1]]:void 0;return!i||"binary_sensor"!==a&&isNaN(i.state)?"—":o.dy`
                ${"sensor"===a?this.hass.formatEntityState(i):o.Ld}
                <ha-battery-icon .hass=${this.hass} .batteryStateObj=${i} .batteryChargingStateObj=${n}></ha-battery-icon>
              `}},created_at:{title:e("ui.panel.config.generic.headers.created_at"),defaultHidden:!0,sortable:!0,filterable:!0,minWidth:"128px",template:e=>e.created_at?(0,h.yD)(new Date(1e3*e.created_at),this.hass.locale,this.hass.config):"—"},modified_at:{title:e("ui.panel.config.generic.headers.modified_at"),defaultHidden:!0,sortable:!0,filterable:!0,minWidth:"128px",template:e=>e.modified_at?(0,h.yD)(new Date(1e3*e.modified_at),this.hass.locale,this.hass.config):"—"},disabled_by:{title:e("ui.panel.config.devices.picker.state"),type:"icon",defaultHidden:!0,sortable:!0,filterable:!0,minWidth:"80px",maxWidth:"80px",template:e=>e.disabled_by?o.dy`
                <div tabindex="0" style="display:inline-block;position:relative">
                  <ha-tooltip placement="left" .content=${this.hass.localize("ui.panel.config.entities.picker.status.disabled")}>
                    <ha-svg-icon .path=${N}></ha-svg-icon>
                  </ha-tooltip>
                </div>
              `:"—"},labels:{title:"",hidden:!0,filterable:!0,template:e=>e.label_entries.map((e=>e.name)).join(" ")}})))}},{kind:"method",key:"hassSubscribe",value:function(){return[(0,x.f4)(this.hass.connection,(e=>{this._labels=e}))]}},{kind:"method",key:"render",value:function(){const{devicesOutput:e}=this._devicesAndFilterDomains(this.hass.devices,this.entries,this.entities,this.hass.areas,this.manifests,this._filters,this.hass.localize,this._labels),t=this._sizeController.value&&this._sizeController.value<700||!this._sizeController.value&&"docked"===this.hass.dockedSidebar,i=o.dy`${Object.values(this.hass.areas).map((e=>o.dy`<ha-md-menu-item .value=${e.area_id} .clickAction=${this._handleBulkArea}>
            ${e.icon?o.dy`<ha-icon slot="start" .icon=${e.icon}></ha-icon>`:o.dy`<ha-svg-icon slot="start" .path=${j}></ha-svg-icon>`}
            <div slot="headline">${e.name}</div>
          </ha-md-menu-item>`))}
      <ha-md-menu-item .value=${null} .clickAction=${this._handleBulkArea}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.no_area")}
        </div>
      </ha-md-menu-item>
      <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>
      <ha-md-menu-item .clickAction=${this._bulkCreateArea}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.add_area")}
        </div>
      </ha-md-menu-item>`,a=o.dy`${this._labels?.map((e=>{const t=e.color?(0,c.I)(e.color):void 0,i=this._selected.every((t=>this.hass.devices[t]?.labels.includes(e.label_id))),a=!i&&this._selected.some((t=>this.hass.devices[t]?.labels.includes(e.label_id)));return o.dy`<ha-md-menu-item .value=${e.label_id} .action=${i?"remove":"add"} @click=${this._handleBulkLabel} keep-open>
          <ha-checkbox slot="start" .checked=${i} .indeterminate=${a} reducedTouchTarget></ha-checkbox>
          <ha-label style=${t?`--color: ${t}`:""}>
            ${e.icon?o.dy`<ha-icon slot="icon" .icon=${e.icon}></ha-icon>`:o.Ld}
            ${e.name}
          </ha-label>
        </ha-md-menu-item>`}))}
      <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>
      <ha-md-menu-item .clickAction=${this._bulkCreateLabel}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.labels.add_label")}
        </div></ha-md-menu-item>`;return o.dy`
      <hass-tabs-subpage-data-table .hass=${this.hass} .narrow=${this.narrow} .backPath=${this._searchParms.has("historyBack")?void 0:"/config"} .tabs=${S.configSections.devices} .route=${this.route} .searchLabel=${this.hass.localize("ui.panel.config.devices.picker.search",{number:e.length})} .columns=${this._columns(this.hass.localize)} .data=${e} selectable .selected=${this._selected.length} @selection-changed=${this._handleSelectionChanged} .filter=${this._filter} has-filters .filters=${Object.values(this._filters).filter((e=>Array.isArray(e.value)?e.value.length:e.value&&Object.values(e.value).some((e=>Array.isArray(e)?e.length:e)))).length} .initialGroupColumn=${this._activeGrouping} .initialCollapsedGroups=${this._activeCollapsed} .initialSorting=${this._activeSorting} .columnOrder=${this._activeColumnOrder} .hiddenColumns=${this._activeHiddenColumns} @columns-changed=${this._handleColumnsChanged} @clear-filter=${this._clearFilter} @search-changed=${this._handleSearchChange} @sorting-changed=${this._handleSortingChanged} @grouping-changed=${this._handleGroupingChanged} @collapsed-changed=${this._handleCollapseChanged} @row-click=${this._handleRowClicked} clickable has-fab class=${this.narrow?"narrow":""}>
        <ha-integration-overflow-menu .hass=${this.hass} slot="toolbar-icon"></ha-integration-overflow-menu>
        <ha-fab slot="fab" .label=${this.hass.localize("ui.panel.config.devices.add_device")} extended @click=${this._addDevice}>
          <ha-svg-icon slot="icon" .path=${Z}></ha-svg-icon>
        </ha-fab>
        ${Array.isArray(this._filters.config_entry?.value)&&this._filters.config_entry?.value.length?o.dy`<ha-alert slot="filter-pane">
              ${this.hass.localize("ui.panel.config.devices.filtering_by_config_entry")}
              ${this.entries?.find((e=>e.entry_id===this._filters.config_entry.value[0]))?.title||this._filters.config_entry.value[0]}${1===this._filters.config_entry.value.length&&Array.isArray(this._filters.sub_entry?.value)&&this._filters.sub_entry.value.length?o.dy` (${this._subEntries?.find((e=>e.subentry_id===this._filters.sub_entry.value[0]))?.title||this._filters.sub_entry.value[0]})`:o.Ld}
            </ha-alert>`:o.Ld}
        <ha-filter-floor-areas .hass=${this.hass} type="device" .value=${this._filters["ha-filter-floor-areas"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-floor-areas"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-floor-areas>
        <ha-filter-integrations .hass=${this.hass} .value=${this._filters["ha-filter-integrations"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-integrations"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-integrations>
        <ha-filter-states .hass=${this.hass} .value=${this._filters["ha-filter-states"]?.value} .states=${this._states(this.hass.localize)} .label=${this.hass.localize("ui.panel.config.devices.picker.state")} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-states"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-states>
        <ha-filter-labels .hass=${this.hass} .value=${this._filters["ha-filter-labels"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-labels"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-labels>

        ${this.narrow?o.Ld:o.dy`<ha-md-button-menu slot="selection-bar">
                <ha-assist-chip slot="trigger" .label=${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.add_label")}>
                  <ha-svg-icon slot="trailing-icon" .path=${H}></ha-svg-icon>
                </ha-assist-chip>
                ${a}
              </ha-md-button-menu>

              ${t?o.Ld:o.dy`<ha-md-button-menu slot="selection-bar">
                    <ha-assist-chip slot="trigger" .label=${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.move_area")}>
                      <ha-svg-icon slot="trailing-icon" .path=${H}></ha-svg-icon>
                    </ha-assist-chip>
                    ${i}
                  </ha-md-button-menu>`}`}
        ${this.narrow||t?o.dy`<ha-md-button-menu has-overflow slot="selection-bar">
              ${this.narrow?o.dy`<ha-assist-chip .label=${this.hass.localize("ui.panel.config.automation.picker.bulk_action")} slot="trigger">
                    <ha-svg-icon slot="trailing-icon" .path=${H}></ha-svg-icon>
                  </ha-assist-chip>`:o.dy`<ha-icon-button .path=${B} .label=${this.hass.localize("ui.panel.config.automation.picker.bulk_action")} slot="trigger"></ha-icon-button>`}
              ${this.narrow?o.dy` <ha-sub-menu>
                    <ha-md-menu-item slot="item">
                      <div slot="headline">
                        ${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.add_label")}
                      </div>
                      <ha-svg-icon slot="end" .path=${P}></ha-svg-icon>
                    </ha-md-menu-item>
                    <ha-menu slot="menu">${a}</ha-menu>
                  </ha-sub-menu>`:o.Ld}
              <ha-sub-menu>
                <ha-md-menu-item slot="item">
                  <div slot="headline">
                    ${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.move_area")}
                  </div>
                  <ha-svg-icon slot="end" .path=${P}></ha-svg-icon>
                </ha-md-menu-item>
                <ha-menu slot="menu">${i}</ha-menu>
              </ha-sub-menu>
            </ha-md-button-menu>`:o.Ld}
      </hass-tabs-subpage-data-table>
    `}},{kind:"method",key:"_loadSubEntries",value:async function(e){this._subEntries=await(0,_.$H)(this.hass,e)}},{kind:"method",key:"_filterExpanded",value:function(e){e.detail.expanded?this._expandedFilter=e.target.localName:this._expandedFilter===e.target.localName&&(this._expandedFilter=void 0)}},{kind:"method",key:"_filterChanged",value:function(e){const t=e.target.localName;this._filters={...this._filters,[t]:e.detail}}},{kind:"method",key:"_batteryEntity",value:function(e,t){const i=(0,$.eD)(this.hass,t[e]||[]);return i?i.entity_id:void 0}},{kind:"method",key:"_batteryChargingEntity",value:function(e,t){const i=(0,$.wX)(this.hass,t[e]||[]);return i?i.entity_id:void 0}},{kind:"method",key:"_handleRowClicked",value:function(e){const t=e.detail.id;this._ignoreLocationChange=!0,(0,m.c)(`/config/devices/device/${t}`)}},{kind:"method",key:"_handleSearchChange",value:function(e){this._filter=e.detail.value,history.replaceState({filter:this._filter},"")}},{kind:"method",key:"_addDevice",value:function(){const{filteredConfigEntry:e,filteredDomains:t}=this._devicesAndFilterDomains(this.hass.devices,this.entries,this.entities,this.hass.areas,this.manifests,this._filters,this.hass.localize,this._labels);1===t.size&&v.S.includes([...t][0])?(0,v.D)(this,this.hass,[...t][0],{config_entry:e?.entry_id}):(0,D.E)(this,{domain:this._searchParms.get("domain")||void 0})}},{kind:"method",key:"_handleSelectionChanged",value:function(e){this._selected=e.detail.value}},{kind:"field",key:"_handleBulkArea",value(){return e=>{const t=e.value;this._bulkAddArea(t)}}},{kind:"method",key:"_bulkAddArea",value:async function(e){const t=[];this._selected.forEach((i=>{t.push((0,w.t1)(this.hass,i,{area_id:e}))}));const i=await Promise.allSettled(t);if((0,p.M)(i)){const e=(0,p.a)(i);(0,C.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.common.multiselect.failed",{number:e.length}),text:o.dy`<pre>
${e.map((e=>e.reason.message||e.reason.code||e.reason)).join("\r\n")}</pre>`})}}},{kind:"field",key:"_bulkCreateArea",value(){return()=>{(0,L.E)(this,{createEntry:async e=>{const t=await(0,y.Lo)(this.hass,e);return this._bulkAddArea(t.area_id),t}})}}},{kind:"method",key:"_handleBulkLabel",value:async function(e){const t=e.currentTarget.value,i=e.currentTarget.action;this._bulkLabel(t,i)}},{kind:"method",key:"_bulkLabel",value:async function(e,t){const i=[];this._selected.forEach((a=>{i.push((0,w.t1)(this.hass,a,{labels:"add"===t?this.hass.devices[a].labels.concat(e):this.hass.devices[a].labels.filter((t=>t!==e))}))}));const a=await Promise.allSettled(i);if((0,p.M)(a)){const e=(0,p.a)(a);(0,C.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.common.multiselect.failed",{number:e.length}),text:o.dy`<pre>
${e.map((e=>e.reason.message||e.reason.code||e.reason)).join("\r\n")}</pre>`})}}},{kind:"field",key:"_bulkCreateLabel",value(){return()=>{(0,M.T)(this,{createEntry:async e=>{const t=await(0,x.jo)(this.hass,e);return this._bulkLabel(t.label_id,"add"),t}})}}},{kind:"method",key:"_handleSortingChanged",value:function(e){this._activeSorting=e.detail}},{kind:"method",key:"_handleGroupingChanged",value:function(e){this._activeGrouping=e.detail.value}},{kind:"method",key:"_handleCollapseChanged",value:function(e){this._activeCollapsed=e.detail.value}},{kind:"method",key:"_handleColumnsChanged",value:function(e){this._activeColumnOrder=e.detail.columnOrder,this._activeHiddenColumns=e.detail.hiddenColumns}},{kind:"get",static:!0,key:"styles",value:function(){return[o.iv`:host{display:block}hass-tabs-subpage-data-table{--data-table-row-height:60px}hass-tabs-subpage-data-table.narrow{--data-table-row-height:72px}ha-button-menu{margin-left:8px;margin-inline-start:8px;margin-inline-end:initial}.clear{color:var(--primary-color);padding-left:8px;padding-inline-start:8px;text-transform:uppercase;direction:var(--direction)}ha-assist-chip{--ha-assist-chip-container-shape:10px}ha-md-button-menu ha-assist-chip{--md-assist-chip-trailing-space:8px}ha-label{--ha-label-background-color:var(--color, var(--grey-color));--ha-label-background-opacity:0.5}`,A.Qx]}}]}}),(0,z.f)(o.oi));t()}catch(e){t(e)}}))},39388:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t);var n=i(44249),s=i(72621),o=i(15093),r=i(75101),l=i(57816),d=i(24312),c=i(7199),h=i(77148),u=e([c,h]);[c,h]=u.then?(await u)():u;(0,n.Z)([(0,o.Mo)("ha-config-devices")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"showAdvanced",value:()=>!1},{kind:"field",key:"routerOptions",value:()=>({defaultPage:"dashboard",routes:{dashboard:{tag:"ha-config-devices-dashboard",cache:!0},device:{tag:"ha-config-device-page"}}})},{kind:"field",decorators:[(0,o.SB)()],key:"_configEntries",value:()=>[]},{kind:"field",decorators:[(0,o.SB)()],key:"_manifests",value:()=>[]},{kind:"method",key:"firstUpdated",value:function(e){(0,s.Z)(i,"firstUpdated",this,3)([e]),this._loadData()}},{kind:"method",key:"updatePageEl",value:function(e){e.hass=this.hass,"device"===this._currentPage&&(e.deviceId=this.routeTail.path.substr(1)),e.entries=this._configEntries,e.manifests=this._manifests,e.narrow=this.narrow,e.isWide=this.isWide,e.showAdvanced=this.showAdvanced,e.route=this.routeTail}},{kind:"method",key:"_loadData",value:async function(){this._configEntries=await(0,r.pB)(this.hass),this._manifests=await(0,l.F3)(this.hass)}}]}}),d.n);a()}catch(e){a(e)}}))},20526:function(e,t,i){i.d(t,{oU:()=>g,lY:()=>m,VG:()=>p,AP:()=>y});i(92745),i(84283),i(9359),i(56475),i(1331),i(31526),i(70104),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814);var a=i(73358),n=i(73850),s=i(59847),o=i(47194);var r=i(12753),l=i(1416),d=i(82100),c=i(57816),h=i(4242),u=i(96530);const f=new Set(["automation","configurator","device_tracker","event","geo_location","notify","persistent_notification","script","sun","tag","todo","zone",...a.a5]),v=new Set(["mobile_app"]),m=(e,t)=>({type:"grid",cards:e.map((e=>({type:"tile",entity:e,show_entity_picture:["camera","image","person"].includes((0,n.M)(e))||void 0}))),...t}),p=(e,t,i,s=!0)=>{const d=[],c=[],h=i.title?i.title.toLowerCase():void 0,u=[];for(const i of t){const t=e[i],a=(0,n.M)(i);if("alarm_control_panel"===a){const e={type:"alarm-panel",entity:i};d.push(e)}else if("camera"===a){const e={type:"picture-entity",entity:i};d.push(e)}else if("image"===a){const e={type:"picture",image_entity:i};d.push(e)}else if("climate"===a){const t={type:"thermostat",entity:i,features:(e[i]?.attributes?.hvac_modes?.length??0)>1?[{type:"climate-hvac-modes",hvac_modes:e[i]?.attributes?.hvac_modes}]:void 0};d.push(t)}else if("humidifier"===a){const e={type:"humidifier",entity:i,features:[{type:"humidifier-toggle"}]};d.push(e)}else if("media_player"===a){const e={type:"media-control",entity:i};d.push(e)}else if("plant"===a){const e={type:"plant-status",entity:i};d.push(e)}else if("weather"===a){const e={type:"weather-forecast",entity:i,show_forecast:!1};d.push(e)}else if(!s||"scene"!==a&&"script"!==a){let e;const a=h&&t&&(e=(0,r.N)((0,o.C)(t),h))?{entity:i,name:e}:i;c.push(a)}else{const e={entity:i,show_icon:!0,show_name:!0};let a;h&&t&&(a=(0,r.N)((0,o.C)(t),h))&&(e.name=a),u.push(e)}}if(c.sort(((t,i)=>{const s="string"==typeof t?t:t.entity,r="string"==typeof i?i:i.entity,d=a.zF.includes((0,n.M)(s))?"sensor":"control";return d!==(a.zF.includes((0,n.M)(r))?"sensor":"control")?"sensor"===d?1:-1:(0,l.$K)("string"==typeof t?e[t]?(0,o.C)(e[t]):"":t.name||"","string"==typeof i?e[i]?(0,o.C)(e[i]):"":i.name||"")})),0===c.length&&u.length>0)return p(e,t,i,!1);if(c.length>0||u.length>0){const e={type:"entities",entities:c,...i};u.length>0&&(e.footer={type:"buttons",entities:u}),d.unshift(e)}return d.length<2?d:[{type:"grid",square:!1,columns:1,cards:d}]},g=(e,t)=>{const i=[];for(const e of t){const t={type:"entity",entity:e};i.push(t)}return i},y=(e,t,i,a,r,m,g,y,_)=>{const b=((e,t)=>{const i={},a=new Set(Object.values(t).filter((e=>e.entity_category||e.platform&&v.has(e.platform)||e.hidden)).map((e=>e.entity_id)));for(const t of Object.keys(e)){const n=e[t];f.has((0,s.N)(n))||a.has(n.entity_id)||(i[t]=e[t])}return i})(a,i),k={};for(const e of Object.keys(b)){const t=b[e];t.attributes.order&&(k[e]=t.attributes.order)}const w=((e,t,i,a)=>{const n={...a},s={},o={};for(const a of Object.values(i)){const i=a.area_id||a.device_id&&t[a.device_id]?.area_id;i&&i in e&&a.entity_id in n?(i in s||(s[i]=[]),s[i].push(n[a.entity_id]),delete n[a.entity_id]):a.device_id&&a.device_id in t&&a.entity_id in n&&(a.device_id in o||(o[a.device_id]=[]),o[a.device_id].push(n[a.entity_id]),delete n[a.entity_id])}for(const[e,t]of Object.entries(o))1===t.length&&(n[t[0].entity_id]=t[0],delete o[e]);return{areasWithEntities:s,devicesWithEntities:o,otherEntities:n}})(e,t,i,b);if(g?.hidden)for(const e of g.hidden)delete w.areasWithEntities[e];y&&(w.devicesWithEntities={},w.otherEntities={});const $=(e=>{const t=[],i={};return Object.keys(e).forEach((a=>{const s=e[a];"group"===(0,n.M)(a)?t.push(s):i[a]=s})),t.forEach((e=>e.attributes.entity_id.forEach((e=>{delete i[e]})))),{groups:t,ungrouped:i}})(w.otherEntities);$.groups.sort(((e,t)=>k[e.entity_id]-k[t.entity_id]));const x=[];for(const e of $.groups)x.push(...p(a,e.attributes.entity_id,{title:(0,o.C)(e),show_header_toggle:"hidden"!==e.attributes.control}));const C=((e,t,i,a,n)=>{const r={};for(const e of Object.keys(n)){const t=n[e],i=(0,s.N)(t);i in r||(r[i]=[]),r[i].push(t.entity_id)}const d=[];if("person"in r){const e=[];if(1===r.person.length)d.push({type:"entities",entities:r.person});else{let t,i="";for(const a of r.person){const s=n[a];let o=s.attributes.entity_picture;if(!o){if(void 0===t){const e=getComputedStyle(document.body);t=encodeURIComponent(e.getPropertyValue("--light-primary-color").trim()),i=encodeURIComponent((e.getPropertyValue("--text-light-primary-color")||e.getPropertyValue("--primary-text-color")).trim())}o=`data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 50 50' width='50' height='50' style='background-color:${t}'%3E%3Cg%3E%3Ctext font-family='roboto' x='50%25' y='50%25' text-anchor='middle' stroke='${i}' font-size='1.3em' dy='.3em'%3E${(0,h.fm)(s.attributes.friendly_name||"")}%3C/text%3E%3C/g%3E%3C/svg%3E`}e.push({type:"picture-entity",entity:a,aspect_ratio:"1",show_name:!1,image:o})}d.push({type:"grid",square:!0,columns:3,cards:e})}delete r.person}const f=[];for(const e of u.y)e in r&&(f.push(...r[e]),delete r[e]);const v={};for(const t of Object.keys(r))v[t]=(0,c.Lh)(e,t);f.length&&(r._helpers=f,v._helpers=e("ui.panel.lovelace.strategy.original-states.helpers")),Object.keys(r).sort(((e,t)=>(0,l.$K)(v[e],v[t]))).forEach((e=>{d.push(...p(n,r[e].sort(((e,t)=>(0,l.$K)((0,o.C)(n[e]),(0,o.C)(n[t])))),{title:v[e]}))}));const m={path:t,title:i,cards:d};return a&&(m.icon=a),m})(r,"default_view","Home",undefined,$.ungrouped),z=[],A=Object.keys(w.areasWithEntities).sort((0,d.a)(e,g?.order));for(const t of A){const i=w.areasWithEntities[t],n=e[t];z.push(...p(a,i.map((e=>e.entity_id)),{title:n.name}))}const E=[],L=Object.entries(w.devicesWithEntities).sort(((e,i)=>{const a=t[e[0]],n=t[i[0]];return(0,l.$K)(a.name_by_user||a.name||"",n.name_by_user||n.name||"")}));for(const[e,i]of L){const n=t[e];E.push(...p(a,i.map((e=>e.entity_id)),{title:n.name_by_user||n.name||r("ui.panel.config.devices.unnamed_device",{type:r(`ui.panel.config.devices.type.${n.entry_type||"device"}`)})}))}let S;if(m&&!_){const e=m.energy_sources.find((e=>"grid"===e.type));e&&e.flow_from.length>0&&(S={title:r("ui.panel.lovelace.cards.energy.energy_distribution.title_today"),type:"energy-distribution",link_dashboard:!0})}return C.cards.unshift(...z,...x,...S?[S]:[]),C.cards.push(...E),C}},40249:function(e,t,i){i.d(t,{ED:()=>u,Fr:()=>o,N2:()=>s,Tw:()=>c,Xm:()=>h});var a=i(36522),n=i(17951);const s=(e,t)=>({type:"error",error:e,origConfig:t}),o=(e,t)=>({type:"error",error:e,origConfig:t}),r=(e,t)=>{const i=document.createElement(e);return i.setConfig(t),i},l=(e,t,a)=>"badge"===e?(e=>{const t=document.createElement("hui-error-badge");return customElements.get("hui-error-badge")?t.setConfig(e):(Promise.all([i.e("35671"),i.e("83895"),i.e("8795"),i.e("32146"),i.e("9296"),i.e("31058"),i.e("63055"),i.e("69577"),i.e("44251"),i.e("52358"),i.e("95752"),i.e("79931"),i.e("60487"),i.e("3371"),i.e("92691"),i.e("38326"),i.e("10745"),i.e("70639"),i.e("25804"),i.e("99633"),i.e("74670")]).then(i.bind(i,72814)),customElements.whenDefined("hui-error-badge").then((()=>{customElements.upgrade(t),t.setConfig(e)}))),t})(o(t,a)):"heading-badge"===e?(e=>{const t=document.createElement("hui-error-heading-badge");return customElements.get("hui-error-heading-badge")?t.setConfig(e):(Promise.all([i.e("35671"),i.e("83895"),i.e("8795"),i.e("32146"),i.e("9296"),i.e("31058"),i.e("63055"),i.e("69577"),i.e("44251"),i.e("52358"),i.e("95752"),i.e("79931"),i.e("60487"),i.e("3371"),i.e("92691"),i.e("38326"),i.e("10745"),i.e("70639"),i.e("25804"),i.e("99633"),i.e("3877")]).then(i.bind(i,5031)),customElements.whenDefined("hui-error-heading-badge").then((()=>{customElements.upgrade(t),t.setConfig(e)}))),t})(((e,t)=>({type:"error",error:e,origConfig:t}))(t,a)):(e=>{const t=document.createElement("hui-error-card");return customElements.get("hui-error-card")?t.setConfig(e):(Promise.all([i.e("83895"),i.e("8795"),i.e("91382")]).then(i.bind(i,53257)),customElements.whenDefined("hui-error-card").then((()=>{customElements.upgrade(t),t.setConfig(e)}))),t})(s(t,a)),d=e=>(0,n.IT)(e)?(0,n.V0)(e):void 0,c=(e,t,i,a,n,s)=>{try{return h(e,t,i,a,n,s)}catch(i){return console.error(e,t.type,i),l(e,i.message,t)}},h=(e,t,i,n,s,o)=>{if(!t||"object"!=typeof t)throw new Error("Config is not an object");if(!(t.type||o||s&&"entity"in t))throw new Error("No card type configured");const c=t.type?d(t.type):void 0;if(c)return((e,t,i)=>{if(customElements.get(t))return r(t,i);const n=l(e,`Custom element doesn't exist: ${t}.`,i);if(!t.includes("-"))return n;n.style.display="None";const s=window.setTimeout((()=>{n.style.display=""}),2e3);return customElements.whenDefined(t).then((()=>{clearTimeout(s),(0,a.B)(n,"ll-rebuild")})),n})(e,c,t);let h;if(s&&!t.type&&t.entity){h=`${s[t.entity.split(".",1)[0]]||s._domain_not_found}-entity`}else h=t.type||o;if(void 0===h)throw new Error("No type specified");const u=`hui-${h}-${e}`;if(n&&h in n)return n[h](),((e,t)=>{if(customElements.get(e))return r(e,t);const i=document.createElement(e);return customElements.whenDefined(e).then((()=>{try{customElements.upgrade(i),(0,a.B)(i,"ll-upgrade"),i.setConfig(t)}catch(e){(0,a.B)(i,"ll-rebuild")}})),i})(u,t);if(i&&i.has(h))return r(u,t);throw new Error(`Unknown type encountered: ${h}`)},u=async(e,t,i,a)=>{const n=d(e);if(n){const e=customElements.get(n);if(e)return e;if(!n.includes("-"))throw new Error(`Custom element not found: ${n}`);return new Promise(((e,t)=>{setTimeout((()=>t(new Error(`Custom element not found: ${n}`))),2e3),customElements.whenDefined(n).then((()=>e(customElements.get(n))))}))}const s=`hui-${e}-${t}`,o=customElements.get(s);if(i&&i.has(e))return o;if(a&&e in a)return o||a[e]().then((()=>customElements.get(s)));throw new Error(`Unknown type: ${e}`)}},46542:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{T:()=>b,m:()=>_});i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814);var n=i(72053),s=i(35659),o=i(52809),r=i(40165),l=i(82114),d=i(21474),c=i(31087),h=i(90296),u=i(42135),f=i(40806),v=i(40249),m=e([n,s,o,r,l,d,c,h,u,f]);[n,s,o,r,l,d,c,h,u,f]=m.then?(await m)():m;const p=new Set(["media-player-entity","scene-entity","script-entity","sensor-entity","simple-entity","toggle-entity","button","call-service"]),g={"button-entity":()=>i.e("44821").then(i.bind(i,35154)),"climate-entity":()=>i.e("79702").then(i.bind(i,54222)),"cover-entity":()=>i.e("50764").then(i.bind(i,4806)),"date-entity":()=>Promise.all([i.e("46379"),i.e("50013")]).then(i.bind(i,61351)),"datetime-entity":()=>Promise.all([i.e("46379"),i.e("41258"),i.e("35671"),i.e("3134"),i.e("3561"),i.e("37311")]).then(i.bind(i,67429)),"event-entity":()=>Promise.resolve().then(i.bind(i,72053)),"group-entity":()=>i.e("83537").then(i.bind(i,40445)),"input-button-entity":()=>i.e("5380").then(i.bind(i,57548)),"humidifier-entity":()=>i.e("84999").then(i.bind(i,88916)),"input-datetime-entity":()=>Promise.all([i.e("46379"),i.e("41258"),i.e("35671"),i.e("3561"),i.e("88438")]).then(i.bind(i,67223)),"input-number-entity":()=>Promise.all([i.e("46379"),i.e("84605")]).then(i.bind(i,90516)),"input-select-entity":()=>Promise.all([i.e("41258"),i.e("35671"),i.e("66868")]).then(i.bind(i,43)),"input-text-entity":()=>Promise.all([i.e("46379"),i.e("14673")]).then(i.bind(i,22623)),"lock-entity":()=>i.e("99689").then(i.bind(i,65751)),"number-entity":()=>Promise.all([i.e("46379"),i.e("88187")]).then(i.bind(i,77288)),"select-entity":()=>Promise.all([i.e("41258"),i.e("35671"),i.e("86857")]).then(i.bind(i,64827)),"text-entity":()=>Promise.all([i.e("46379"),i.e("86449")]).then(i.bind(i,90689)),"time-entity":()=>Promise.all([i.e("46379"),i.e("41258"),i.e("35671"),i.e("3561"),i.e("46309")]).then(i.bind(i,4671)),"timer-entity":()=>i.e("7618").then(i.bind(i,45363)),"update-entity":()=>i.e("58400").then(i.bind(i,97604)),"valve-entity":()=>i.e("96347").then(i.bind(i,97937)),conditional:()=>i.e("79220").then(i.bind(i,24272)),"weather-entity":()=>Promise.all([i.e("44251"),i.e("28565")]).then(i.bind(i,51973)),divider:()=>i.e("73576").then(i.bind(i,70568)),section:()=>i.e("26438").then(i.bind(i,93665)),weblink:()=>i.e("41871").then(i.bind(i,69819)),cast:()=>i.e("45006").then(i.bind(i,15638)),buttons:()=>Promise.all([i.e("59821"),i.e("73644")]).then(i.bind(i,58574)),attribute:()=>Promise.resolve().then(i.bind(i,90296)),text:()=>i.e("52767").then(i.bind(i,68291))},y={_domain_not_found:"simple",alert:"toggle",automation:"toggle",button:"button",climate:"climate",cover:"cover",date:"date",datetime:"datetime",event:"event",fan:"toggle",group:"group",humidifier:"humidifier",input_boolean:"toggle",input_button:"input-button",input_datetime:"input-datetime",input_number:"input-number",input_select:"input-select",input_text:"input-text",light:"toggle",lock:"lock",media_player:"media-player",number:"number",remote:"toggle",scene:"scene",script:"script",select:"select",sensor:"sensor",siren:"toggle",switch:"toggle",text:"text",time:"time",timer:"timer",update:"update",vacuum:"toggle",valve:"valve",water_heater:"climate",weather:"weather"},_=e=>(0,v.Tw)("row",e,p,g,y,void 0),b=e=>(0,v.ED)(e,"row",p,g);a()}catch(e){a(e)}}))},69615:function(e,t,i){i.d(t,{$:()=>l});i(9359),i(56475);var a=i(48977),n=i(6649),s=i(76131),o=i(53380),r=i(74941);const l=async(e,t,i,l,d)=>{t.loadFragmentTranslation("lovelace");const c=await(0,n.j2)(t),h=c.filter((e=>"storage"===e.mode)),u=t.panels.lovelace?.config?.mode;if("storage"!==u&&!h.length)return void(0,o.f)(e,{cardConfig:i,entities:d,yaml:!0});let f,v=null;if("storage"===u)try{f=await(0,a.Q2)(t.connection,null,!1)}catch(e){}if(!f&&h.length)for(const e of h)try{f=await(0,a.Q2)(t.connection,e.url_path,!1),v=e.url_path;break}catch(e){}f?h.length||f.views?.length?h.length||1!==f.views.length?(0,r.i)(e,{lovelaceConfig:f,urlPath:v,allowDashboardChange:!0,actionLabel:t.localize("ui.common.next"),dashboards:c,viewSelectedCallback:(n,s,r)=>{(0,o.f)(e,{cardConfig:i,sectionConfig:l,lovelaceConfig:s,saveConfig:async e=>{try{await(0,a.Oh)(t,n,e)}catch{alert(t.localize("ui.panel.lovelace.add_entities.saving_failed"))}},path:[r],entities:d})}}):(0,o.f)(e,{cardConfig:i,sectionConfig:l,lovelaceConfig:f,saveConfig:async e=>{try{await(0,a.Oh)(t,null,e)}catch(e){alert(t.localize("ui.panel.lovelace.add_entities.saving_failed"))}},path:[0],entities:d}):(0,s.showAlertDialog)(e,{text:"You don't have any Lovelace views, first create a view in Lovelace."}):c.length>h.length?(0,o.f)(e,{cardConfig:i,sectionConfig:l,entities:d,yaml:!0}):(0,s.showAlertDialog)(e,{text:"You don't seem to be in control of any dashboard, please take control first."})}},53380:function(e,t,i){i.d(t,{f:()=>s});var a=i(36522);const n=()=>Promise.all([i.e("35671"),i.e("83895"),i.e("29570"),i.e("65505"),i.e("8795"),i.e("71588"),i.e("92139"),i.e("32146"),i.e("9296"),i.e("47399"),i.e("74407"),i.e("63055"),i.e("44251"),i.e("52358"),i.e("95752"),i.e("60487"),i.e("92691"),i.e("38326"),i.e("16912"),i.e("70639"),i.e("92368"),i.e("85662"),i.e("45066"),i.e("80312"),i.e("51856")]).then(i.bind(i,22958)),s=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"hui-dialog-suggest-card",dialogImport:n,dialogParams:t})}},74941:function(e,t,i){i.d(t,{i:()=>n});var a=i(36522);const n=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"hui-dialog-select-view",dialogImport:()=>Promise.all([i.e("97983"),i.e("41258"),i.e("35671"),i.e("7010"),i.e("5851")]).then(i.bind(i,67271)),dialogParams:t})}},58014:function(e,t,i){i.d(t,{N:()=>n,G:()=>s});var a=i(18117);const n=(e,t="")=>{const i=document.createElement("a");i.target="_blank",i.href=e,i.download=t,i.style.display="none",document.body.appendChild(i),i.dispatchEvent(new MouseEvent("click")),document.body.removeChild(i)},s=e=>!(e=>!!e.auth.external&&a.G)(e)||!!e.auth.external?.config.downloadFileSupported},18117:function(e,t,i){i.d(t,{G:()=>a});const a=/^((?!chrome|android).)*safari/i.test(navigator.userAgent)},68783:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{A:()=>c});var n=i(64699),s=i(15073),o=i(81048),r=i(31027),l=i(57243),d=e([s]);s=(d.then?(await d)():d)[0];var c=class extends r.P{constructor(){super(...arguments),this.localize=new s.V(this)}render(){return l.dy`
      <svg part="base" class="spinner" role="progressbar" aria-label=${this.localize.term("loading")}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `}};c.styles=[o.N,n.D],a()}catch(e){a(e)}}))},64699:function(e,t,i){i.d(t,{D:()=>a});var a=i(57243).iv`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`},97677:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{Z:()=>n.A});var n=i(68783),s=(i(64699),i(15073)),o=i(21262),r=(i(81048),i(31027),i(52812),e([s,o,n]));[s,o,n]=r.then?(await r)():r,a()}catch(e){a(e)}}))},43580:function(e,t,i){i.d(t,{Z:()=>a.D});var a=i(64699);i(52812)}};
//# sourceMappingURL=19956.aa00b55cba3d2737.js.map